<div class="row-fluid">	

                                <a class="quick-button metro black  span3" href="<?=  site_url('admin/main_menus')?>">
					<i class="icon-dashboard"></i>
					<p>Main Menus</p>
					<!--<span class="badge">237</span>-->
				</a>
                                <a class="quick-button metro black  span3" href="<?=  site_url('admin/cats')?>">
					<i class="icon-dashboard"></i>
					<p>Categories</p>
					<!--<span class="badge">237</span>-->
				</a>
                                <a class="quick-button metro black  span3" href="<?=  site_url('admin/products')?>">
					<i class="icon-dashboard"></i>
					<p>Products</p>
					<!--<span class="badge">237</span>-->
				</a>
                                <a class="quick-button metro black  span3" href="<?=  site_url('admin/slides')?>">
					<i class="icon-dashboard"></i>
					<p>Slider</p>
					<!--<span class="badge">237</span>-->
				</a>
<!--    				<a class="quick-button metro black span2" href="<?=  site_url('admin/sub_menus')?>">
					<i class="icon-dashboard"></i>
					<p>Sub Menus</p>
					<span class="badge">237</span>
				</a>-->
<!--    				<a class="quick-button metro black span2" href="<?=  site_url('admin/events')?>">
					<i class="icon-dashboard"></i>
					<p>Manage Events</p>
					<span class="badge">237</span>
				</a>-->
<!--    				<a class="quick-button metro black span2" href="<?=  site_url('admin/activities')?>">
					<i class="icon-dashboard"></i>
					<p>Activities</p>
					<span class="badge">237</span>
				</a>-->
<!--                                <a class="quick-button metro black span2" href="<?=  site_url('admin/activity_uploads')?>">
					<i class="icon-dashboard"></i>
					<p>Activity Picture Uploads</p>
					<span class="badge">237</span>
				</a>-->
<!--    				<a class="quick-button metro black span2" href="<?=  site_url('admin/sections')?>">
					<i class="icon-dashboard"></i>
					<p>Manage Blog Sections</p>
					<span class="badge">237</span>
				</a>-->
<!--    				<a class="quick-button metro black span2" href="<?=  site_url('admin/posts')?>">
					<i class="icon-dashboard"></i>
					<p>Blog Posts</p>
					<span class="badge">237</span>
				</a>
    				
    				<a class="quick-button metro black span2" href="<?=  site_url('admin/news')?>">
					<i class="icon-dashboard"></i>
					<p>News</p>
					<span class="badge">237</span>
				</a>-->
    
				
				<div class="clearfix"></div>
								
			</div>