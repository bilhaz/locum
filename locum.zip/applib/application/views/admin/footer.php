
	</div><!--/.fluid-container-->
	
			<!-- end: Content -->
		</div><!--/#content.span10-->
		</div><!--/fluid-row-->
		
	
	
	<div class="clearfix"></div>
	
	<footer>

		<p>
			<span style="text-align:left;float:left">&copy; 2018 <a href="http://pyzie.com">Pyzie</a></span>
			
		</p>

	</footer>
	
	<!-- start: JavaScript-->

		<script src="<?=site_url('assets/admin/js/jquery-1.9.1.min.js')?>"></script>
	<script src="<?=site_url('assets/admin/js/jquery-migrate-1.0.0.min.js')?>"></script>
	
		<script src="<?=site_url('assets/admin/js/jquery-ui-1.10.0.custom.min.js')?>"></script>
	
		<script src="<?=site_url('assets/admin/js/jquery.ui.touch-punch.js')?>"></script>
	
		<!--<script src="<?=site_url('js/modernizr.js')?>"></script>-->
	
		<script src="<?=site_url('assets/admin/js/bootstrap.min.js')?>"></script>
	
		<!--<script src="<?=site_url('assets/admin/js/jquery.cookie.js')?>"></script>-->
	
		<!--<script src='<?=site_url('assets/admin/js/fullcalendar.min.js')?>'></script>-->
	
		<!--<script src='<?=site_url('assets/admin/js/jquery.dataTables.min.js')?>'></script>-->

		<!--<script src="<?=site_url('assets/admin/js/excanvas.js')?>"></script>-->
	<!--<script src="<?=site_url('assets/admin/js/jquery.flot.js')?>"></script>-->
	<!--<script src="<?=site_url('assets/admin/js/jquery.flot.pie.js')?>"></script>-->
	<!--<script src="<?=site_url('assets/admin/js/jquery.flot.stack.js')?>"></script>-->
	<!--<script src="<?=site_url('assets/admin/js/jquery.flot.resize.min.js')?>"></script>-->
	
<!--		<script src="<?=site_url('assets/admin/js/jquery.chosen.min.js')?>"></script>
	
		<script src="<?=site_url('assets/admin/js/jquery.uniform.min.js')?>"></script>
		
		<script src="<?=site_url('assets/admin/js/jquery.cleditor.min.js')?>"></script>
	
		<script src="<?=site_url('assets/admin/js/jquery.noty.js')?>"></script>
	
		<script src="<?=site_url('assets/admin/js/jquery.elfinder.min.js')?>"></script>
	
		<script src="<?=site_url('assets/admin/js/jquery.raty.min.js')?>"></script>
	
		<script src="<?=site_url('assets/admin/js/jquery.iphone.toggle.js')?>"></script>
	
		<script src="<?=site_url('assets/admin/js/jquery.uploadify-3.1.min.js')?>"></script>
	
		<script src="<?=site_url('assets/admin/js/jquery.gritter.min.js')?>"></script>
	
		<script src="<?=site_url('assets/admin/js/jquery.imagesloaded.js')?>"></script>
	
		<script src="<?=site_url('assets/admin/js/jquery.masonry.min.js')?>"></script>
	
		<script src="<?=site_url('assets/admin/js/jquery.knob.modified.js')?>"></script>
	
		<script src="<?=site_url('assets/admin/js/jquery.sparkline.min.js')?>"></script>
	
		<script src="<?=site_url('assets/admin/js/counter.js')?>"></script>
	
		<script src="<?=site_url('assets/admin/js/retina.js')?>"></script>-->

		<script src="<?=site_url('assets/admin/js/custom.js')?>"></script>
	<!-- end: JavaScript-->
	
</body>
</html>