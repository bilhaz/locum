 <main class="site-content" role="main" itemscope="itemscope" itemprop="mainContentOfPage">
            <article id="post-701" class="post-701 page type-page status-publish hentry badges-style-3">
               <div class="entry-content">
                  <div class="elementor elementor-701">
                     <div class="elementor-inner">
                        <div class="elementor-section-wrap">
                           <section data-id="39b5458" class="elementor-element elementor-element-39b5458 elementor-section-stretched elementor-reverse-mobile elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;,&quot;background_background&quot;:&quot;classic&quot;}" data-element_type="section">
                              <div class="elementor-container elementor-column-gap-default">
                                 <div class="elementor-row">
                                    <div data-id="15a7267" class="elementor-element elementor-element-15a7267 elementor-column elementor-col-25 elementor-top-column" data-element_type="column">
                                       <div class="elementor-column-wrap elementor-element-populated">
                                          <div class="elementor-widget-wrap">
                                             <div data-id="fafab08" class="elementor-element elementor-element-fafab08 elementor-widget elementor-widget-text-editor" data-element_type="text-editor.default">
                                                <div class="elementor-widget-container">
                                                   <div class="elementor-text-editor elementor-clearfix">
                                                      <div style="font-size: 14px; color: #fff; text-transform: uppercase; height: 50px; line-height: 50px; font-weight: 500;">Categories</div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div data-id="2d09d35" class="elementor-element elementor-element-2d09d35 elementor-column elementor-col-50 elementor-top-column" data-element_type="column">
                                       <div class="elementor-column-wrap elementor-element-populated">
                                          <div class="elementor-widget-wrap">
                                             <div data-id="9067c0d" class="elementor-element elementor-element-9067c0d elementor-widget elementor-widget-wp-widget-dgwt_wcas_ajax_search" data-element_type="wp-widget-dgwt_wcas_ajax_search.default">
                                                <div class="elementor-widget-container">
                                                   <div class="dgwt-wcas-search-wrapp dgwt-wcas-is-detail-box">
                                                       <form class="dgwt-wcas-search-form" role="search" action="<?=  site_url('home/search')?>" method="get">
                                                         <div class="dgwt-wcas-sf-wrapp">
                                                            <label class="screen-reader-text" for="dgwt-wcas-search">Products search</label> <input 
                                                               type="search"
                                                               class="dgwt-wcas-search-input"
                                                               name="search"
                                                               value="<?=$this->input->get('search')?>"
                                                               placeholder="Search by Product Name"
                                                               />
                                                            <div class="dgwt-wcas-preloader"></div>
                                                            <button type="submit" class="dgwt-wcas-search-submit">Search</button> <input type="hidden" name="post_type" value="product" /> 
                                                         </div>
                                                      </form>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                    <div data-id="24876e4" class="elementor-element elementor-element-24876e4 elementor-hidden-phone elementor-hidden-tablet elementor-column elementor-col-25 elementor-top-column" data-element_type="column">
                                       <div class="elementor-column-wrap elementor-element-populated">
                                          <div class="elementor-widget-wrap">
                                             <div data-id="90608ef" class="elementor-element elementor-element-90608ef elementor-hidden-mobile elementor-hidden-tablet elementor-widget elementor-widget-text-editor" data-element_type="text-editor.default">
                                                <div class="elementor-widget-container">
                                                   <div class="elementor-text-editor elementor-clearfix">
                                                      <div style="font-size: 15px; color: #262626; height: 50px; line-height: 50px; font-weight: 500; text-align: right;"><i class="chromium-icon-telephone-call-receiver" style="display: inline-block; padding: 0; font-size: 16px; color: #fff; transform: rotate(90deg);"></i><a href="tel:0 (800) 423-754" style="color:inherit; padding-left: 15px;">0 (800) 423-754</a></div>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>
                                 </div>
                              </div>
                           </section>
                           <section data-id="45381ba" class="elementor-element elementor-element-45381ba elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;,&quot;background_background&quot;:&quot;classic&quot;}" data-element_type="section">
                              <div class="elementor-container elementor-column-gap-default">
                                 <div class="elementor-row">
                                    <div data-id="6044510" class="elementor-element elementor-element-6044510 elementor-column elementor-col-50 elementor-top-column" data-element_type="column">
                                       <div class="elementor-column-wrap elementor-element-populated">
                                          <div class="elementor-widget-wrap">
                                             <div data-id="5e1649a" class="elementor-element elementor-element-5e1649a elementor-widget elementor-widget-tz-hoverable-tabs" data-element_type="tz-hoverable-tabs.default">
                                                <div class="elementor-widget-container">
                                                   <style id="elementor-post-2392">.elementor-2392 .elementor-element.elementor-element-105ae5e3{background-image:url("wp-content/uploads/sites/2/2018/04/megamenu_bg23.png");background-position:bottom right;background-repeat:no-repeat;transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;padding:30px 15px 30px 15px;}.elementor-2392 .elementor-element.elementor-element-105ae5e3 > .elementor-background-overlay{transition:background 0.3s, border-radius 0.3s, opacity 0.3s;}.elementor-2392 .elementor-element.elementor-element-75e0f6ea > .elementor-element-populated{padding:0px 15px 0px 15px;}.elementor-2392 .elementor-element.elementor-element-32008fdd{color:#626262;font-size:14px;line-height:2em;}.elementor-2392 .elementor-element.elementor-element-32008fdd .elementor-widget-container{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;}.elementor-2392 .elementor-element.elementor-element-5175c7be{color:#626262;font-size:14px;line-height:2em;}.elementor-2392 .elementor-element.elementor-element-5175c7be .elementor-widget-container{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;}.elementor-2392 .elementor-element.elementor-element-4b22e807{color:#626262;font-size:14px;line-height:2em;}.elementor-2392 .elementor-element.elementor-element-4b22e807 .elementor-widget-container{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;}.elementor-2392 .elementor-element.elementor-element-61a1893b > .elementor-element-populated{padding:0px 15px 0px 15px;}.elementor-2392 .elementor-element.elementor-element-20673a28{color:#626262;font-size:14px;line-height:2em;}.elementor-2392 .elementor-element.elementor-element-20673a28 .elementor-widget-container{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;}.elementor-2392 .elementor-element.elementor-element-4ac6b41a{color:#626262;font-size:14px;line-height:2em;}.elementor-2392 .elementor-element.elementor-element-4ac6b41a .elementor-widget-container{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;}.elementor-2392 .elementor-element.elementor-element-60a244f > .elementor-element-populated{padding:0px 15px 0px 15px;}.elementor-2392 .elementor-element.elementor-element-50ea341d{color:#626262;font-size:14px;line-height:2em;}.elementor-2392 .elementor-element.elementor-element-50ea341d .elementor-widget-container{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;}.elementor-2392 .elementor-element.elementor-element-515f3b28{color:#626262;font-size:14px;line-height:2em;}.elementor-2392 .elementor-element.elementor-element-515f3b28 .elementor-widget-container{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;}.elementor-2392 .elementor-element.elementor-element-57f9e58c > .elementor-element-populated{padding:0px 15px 0px 15px;}.elementor-2392 .elementor-element.elementor-element-71bd6233{color:#626262;font-size:14px;line-height:2em;}.elementor-2392 .elementor-element.elementor-element-71bd6233 .elementor-widget-container{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;}@media(max-width:767px){.elementor-2392 .elementor-element.elementor-element-105ae5e3{margin-top:0px;margin-bottom:0px;padding:30px 0px 125px 0px;}.elementor-2392 .elementor-element.elementor-element-75e0f6ea{width:50%;}.elementor-2392 .elementor-element.elementor-element-75e0f6ea > .elementor-element-populated{padding:0px 7px 0px 0px;}.elementor-2392 .elementor-element.elementor-element-61a1893b{width:50%;}.elementor-2392 .elementor-element.elementor-element-61a1893b > .elementor-element-populated{padding:0px 0px 0px 7px;}.elementor-2392 .elementor-element.elementor-element-60a244f{width:50%;}.elementor-2392 .elementor-element.elementor-element-60a244f > .elementor-element-populated{padding:0px 7px 0px 0px;}.elementor-2392 .elementor-element.elementor-element-57f9e58c{width:50%;}.elementor-2392 .elementor-element.elementor-element-57f9e58c > .elementor-element-populated{padding:0px 0px 0px 7px;}}</style>
                                                   <style id="elementor-post-2325">.elementor-2325 .elementor-element.elementor-element-105ae5e3{background-image:url("wp-content/uploads/sites/2/2018/04/Dropdown_image.png");background-position:bottom right;background-repeat:no-repeat;transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;padding:30px 15px 30px 15px;}.elementor-2325 .elementor-element.elementor-element-105ae5e3 > .elementor-background-overlay{transition:background 0.3s, border-radius 0.3s, opacity 0.3s;}.elementor-2325 .elementor-element.elementor-element-75e0f6ea > .elementor-element-populated{padding:0px 15px 0px 15px;}.elementor-2325 .elementor-element.elementor-element-32008fdd{color:#626262;font-size:14px;line-height:2em;}.elementor-2325 .elementor-element.elementor-element-32008fdd .elementor-widget-container{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;}.elementor-2325 .elementor-element.elementor-element-5175c7be{color:#626262;font-size:14px;line-height:2em;}.elementor-2325 .elementor-element.elementor-element-5175c7be .elementor-widget-container{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;}.elementor-2325 .elementor-element.elementor-element-4b22e807{color:#626262;font-size:14px;line-height:2em;}.elementor-2325 .elementor-element.elementor-element-4b22e807 .elementor-widget-container{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;}.elementor-2325 .elementor-element.elementor-element-61a1893b > .elementor-element-populated{padding:0px 15px 0px 15px;}.elementor-2325 .elementor-element.elementor-element-20673a28{color:#626262;font-size:14px;line-height:2em;}.elementor-2325 .elementor-element.elementor-element-20673a28 .elementor-widget-container{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;}.elementor-2325 .elementor-element.elementor-element-4ac6b41a{color:#626262;font-size:14px;line-height:2em;}.elementor-2325 .elementor-element.elementor-element-4ac6b41a .elementor-widget-container{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;}.elementor-2325 .elementor-element.elementor-element-60a244f > .elementor-element-populated{padding:0px 15px 0px 15px;}.elementor-2325 .elementor-element.elementor-element-515f3b28{color:#626262;font-size:14px;line-height:2em;}.elementor-2325 .elementor-element.elementor-element-515f3b28 .elementor-widget-container{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;}.elementor-2325 .elementor-element.elementor-element-50ea341d{color:#626262;font-size:14px;line-height:2em;}.elementor-2325 .elementor-element.elementor-element-50ea341d .elementor-widget-container{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;}.elementor-2325 .elementor-element.elementor-element-57f9e58c > .elementor-element-populated{padding:0px 15px 0px 15px;}.elementor-2325 .elementor-element.elementor-element-71bd6233{color:#626262;font-size:14px;line-height:2em;}.elementor-2325 .elementor-element.elementor-element-71bd6233 .elementor-widget-container{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;}@media(max-width:767px){.elementor-2325 .elementor-element.elementor-element-105ae5e3{padding:20px 15px 125px 15px;}.elementor-2325 .elementor-element.elementor-element-75e0f6ea{width:50%;}.elementor-2325 .elementor-element.elementor-element-75e0f6ea > .elementor-element-populated{padding:0px 7px 0px 0px;}.elementor-2325 .elementor-element.elementor-element-61a1893b{width:50%;}.elementor-2325 .elementor-element.elementor-element-61a1893b > .elementor-element-populated{padding:0px 0px 0px 7px;}.elementor-2325 .elementor-element.elementor-element-60a244f{width:50%;}.elementor-2325 .elementor-element.elementor-element-60a244f > .elementor-element-populated{padding:0px 7px 0px 0px;}.elementor-2325 .elementor-element.elementor-element-57f9e58c{width:50%;}.elementor-2325 .elementor-element.elementor-element-57f9e58c > .elementor-element-populated{padding:0px 0px 0px 7px;}}</style>
                                                   <style id="elementor-post-2233">.elementor-2233 .elementor-element.elementor-element-5e9101f6{background-image:url("wp-content/uploads/sites/2/2018/04/menu_light_upd.png");background-position:top left;background-repeat:no-repeat;transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;margin-top:0px;margin-bottom:0px;padding:30px 15px 30px 15px;}.elementor-2233 .elementor-element.elementor-element-5e9101f6 > .elementor-background-overlay{transition:background 0.3s, border-radius 0.3s, opacity 0.3s;}.elementor-2233 .elementor-element.elementor-element-6853c5f6.elementor-column .elementor-column-wrap{align-items:flex-end;}.elementor-2233 .elementor-element.elementor-element-6853c5f6 > .elementor-element-populated{padding:0px 15px 0px 15px;}.elementor-2233 .elementor-element.elementor-element-5c7b398f{color:#626262;font-size:14px;line-height:2em;}.elementor-2233 .elementor-element.elementor-element-5c7b398f .elementor-widget-container{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;}.elementor-2233 .elementor-element.elementor-element-5ed4af85.elementor-column .elementor-column-wrap{align-items:flex-end;}.elementor-2233 .elementor-element.elementor-element-5ed4af85 > .elementor-element-populated{padding:0px 15px 0px 15px;}.elementor-2233 .elementor-element.elementor-element-3368a0f5{color:#626262;font-size:14px;line-height:2em;}.elementor-2233 .elementor-element.elementor-element-3368a0f5 .elementor-widget-container{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;}.elementor-2233 .elementor-element.elementor-element-44bfde23 > .elementor-element-populated{padding:0px 15px 0px 15px;}.elementor-2233 .elementor-element.elementor-element-461a5b4e{color:#626262;font-size:14px;line-height:2em;}.elementor-2233 .elementor-element.elementor-element-461a5b4e .elementor-widget-container{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;}.elementor-2233 .elementor-element.elementor-element-ce72502{color:#626262;font-size:14px;line-height:2em;}.elementor-2233 .elementor-element.elementor-element-ce72502 .elementor-widget-container{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;}.elementor-2233 .elementor-element.elementor-element-0933545{color:#626262;font-size:14px;line-height:2em;}.elementor-2233 .elementor-element.elementor-element-0933545 .elementor-widget-container{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;}.elementor-2233 .elementor-element.elementor-element-4856217 > .elementor-element-populated{padding:0px 15px 0px 15px;}.elementor-2233 .elementor-element.elementor-element-13c2b1d3{color:#626262;font-size:14px;line-height:2em;}.elementor-2233 .elementor-element.elementor-element-13c2b1d3 .elementor-widget-container{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;}.elementor-2233 .elementor-element.elementor-element-4503316{color:#626262;font-size:14px;line-height:2em;}.elementor-2233 .elementor-element.elementor-element-4503316 .elementor-widget-container{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;}.elementor-2233 .elementor-element.elementor-element-816d436{color:#626262;font-size:14px;line-height:2em;}.elementor-2233 .elementor-element.elementor-element-816d436 .elementor-widget-container{transition:background 0.3s, border 0.3s, border-radius 0.3s, box-shadow 0.3s;}@media(max-width:767px){.elementor-2233 .elementor-element.elementor-element-5e9101f6{padding:250px 0px 0px 0px;}.elementor-2233 .elementor-element.elementor-element-6853c5f6{width:50%;}.elementor-2233 .elementor-element.elementor-element-5ed4af85{width:50%;}.elementor-2233 .elementor-element.elementor-element-44bfde23{width:50%;}.elementor-2233 .elementor-element.elementor-element-4856217{width:50%;}}</style>
                                                   <div class="tz-hoverable-tabs">
                                                      <ul class="nav">
                                                          
                                                         <?php 
                                                         $secs=$this->base_model->get_sections();
                                                            foreach($secs as $sec):
                                                                if($sec->hasCat){ ?>
                                                          <li class="">
                                                                    <?= $sec->name; ?>
                                                                    <div class="inner-content" style="visibility: hidden;width: 70%">
                                                                       <div class="elementor elementor-2410">
                                                                           <div class="elementor-inner" >
                                                                             <div class="elementor-section-wrap">
                                                                                <section data-id="105ae5e3" class="elementor-element elementor-element-105ae5e3 elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-element_type="section">
                                                                                   <div class="elementor-container elementor-column-gap-default">
                                                                                      <div class="elementor-row">
                                                                                          <div data-id="75e0f6ea" class="elementor-element elementor-element-75e0f6ea elementor-column elementor-col-25 elementor-top-column" data-element_type="column" style="width:100%;">
                                                                                            <div class="elementor-column-wrap elementor-element-populated">
                                                                                               <div class="elementor-widget-wrap">
                                                                                                 
                                                                                                  <div data-id="32008fdd" class="elementor-element elementor-element-32008fdd elementor-widget elementor-widget-text-editor" data-element_type="text-editor.default">
                                                                                                     <div class="elementor-widget-container">
                                                                                                        <div class="elementor-text-editor elementor-clearfix">
                                                                                                           <h5 style="font-weight: 500; font-size: 12px; display: block; margin-bottom: 10px;"><a href="#"><?= $sec->name; ?></a></h5>
                                                                                                           <p>
                                                                                                           
                                                                                                            <?php 
                                                                                                                    $cats=$this->admin_model->get_cats_by_section($sec->secId);
                                                                                                              foreach($cats as $cat):
                                                                                                              ?>
                                                                                                                      <a href="<?=  site_url("home/category/$cat->name/$cat->catId/")?>"><?=$cat->name?></a><br>


                                                                                                             <?php   endforeach; ?>
                                                                                                                      </p>
                                                                                                                      </div>
                                                                                                     </div>
                                                                                                  </div>
                                                                                                  
                                                                                               </div>
                                                                                            </div>
                                                                                         </div>
                                                                                          </div>
                                                                                   </div>
                                                                                </section>
                                                                             </div>
                                                                          </div>
                                                                       </div>
                                                                    </div>
                                                                    <i class="icon"></i>
                                                                 </li>
                                                               <?php } else { ?>
                                                                 <li><a style="index:1000" href="<?=  site_url("home/section/$sec->name/$sec->secId/")?>"><?=$sec->name?></a></li>
                                                           <?php } ?>
                                                          <?php endforeach; ?>
                                                        
                                                      </ul>
                                                   </div>
                                                </div>
                                             </div>
                                          </div>
                                       </div>
                                    </div>