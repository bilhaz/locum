
<?php // $this->load->view('categories')?>

<div class="col-lg-12" style="background-color:#fff"><br><br><br><br>
    <a href="<?=  site_url('assets/contact.jpg')?>"><img src="<?=  site_url('assets/contact.jpg')?>" style="width: 100%"/></a>
        
    </div>
