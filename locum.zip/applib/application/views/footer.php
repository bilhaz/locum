</div>

<script src="<?= site_url('assets/js/jquery-3.5.1.min.js') ?>"></script>

<script src="<?= site_url('assets/js/popper.min.js') ?>"></script>
<script src="<?= site_url('assets/js/bootstrap.min.js') ?>"></script>

<script src="<?= site_url('assets/plugins/swiper/js/swiper.min.js') ?>"></script>

<script src="<?= site_url('assets/js/script.js') ?>"></script>
</body>
</html>