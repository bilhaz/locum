<main class="site-content" role="main" itemscope="itemscope" itemprop="mainContentOfPage" style="padding: 0px;margin-bottom: 0px">
    <article id="post-5" class="post-5 page type-page status-publish hentry badges-style-3" style="background: #FFF">
       <br>
       <h2 class="page-title"> &nbsp;&nbsp;&nbsp;&nbsp;<?=$pages['name']?></h2>
      <div class="entry-content">
         <div class="elementor elementor-5">
            <div class="elementor-inner">
               <div class="elementor-section-wrap">
                  <!--<section data-id="2a04ebc5" class="elementor-element elementor-element-2a04ebc5 elementor-section-stretched elementor-section-boxed elementor-section-height-default elementor-section-height-default elementor-section elementor-top-section" data-settings="{&quot;stretch_section&quot;:&quot;section-stretched&quot;,&quot;background_background&quot;:&quot;classic&quot;}" data-element_type="section" style="width: 1583px; left: -206.5px;">-->
                     <div class="elementor-container elementor-column-gap-default">
                         <div class="elementor-row" style="padding: 5px">
                           <?=$pages['content']?>
                        </div>
                     </div>
                  <!--</section>-->
                   <br>
                   <br>
               </div>
            </div>
         </div>
      </div>
   </article>
</main>