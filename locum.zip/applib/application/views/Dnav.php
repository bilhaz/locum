<div class="list-group">
    <a class="list-group-item disabled" style="background-color:#00be95;color: #fff ">
        Dashboard
    </a>
    <a href="<?= site_url('subscribers/orders') ?>" class="list-group-item"><span class="fa fa-suitcase"></span> Orders History</a>
    <a href="<?= site_url('subscribers/profile') ?>" class="list-group-item"><span class="fa fa-user-circle"></span> Profile Settings</a>
    <a href="<?= site_url() ?>" class="list-group-item"><span class="fa fa-shopping-bag"></span> Shopping</a>
</div>