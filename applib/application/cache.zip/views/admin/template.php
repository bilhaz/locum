<?php

    $this->load->view('admin/header');
    $this->load->view($page);
    $this->load->view('admin/footer');