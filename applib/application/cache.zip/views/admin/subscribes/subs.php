<script>
function confirmDelete(){
var agree = confirm("Are you sure you want to delete this ?");
  if(agree == true){
    return true
}
else{
return false;
}
}
</script>
<div class="row-fluid sortable">		
    <div class="box span12" style=" min-height: 400px">
					<div class="box-header" data-original-title>
						<h2><i class="halflings-icon user"></i><span class="break"></span>Subscriptions </h2>
<!--						<div class="box-icon">
							<a href="#" class="btn-setting"><i class="halflings-icon wrench"></i></a>
							<a href="#" class="btn-minimize"><i class="halflings-icon chevron-up"></i></a>
							<a href="#" class="btn-close"><i class="halflings-icon remove"></i></a>
						</div>-->
					</div>
                                   
					<div class="box-content span5">
                                            <h4>Emails List</h4>
						 <?php
                                                 foreach ($emails as $email):
                                                     echo $email['email'].';<br>';
                                                 endforeach;
                                                 
                                                 ?>          
					</div>
                                    
                                        <div class="box-content span5">
                                            <h4>Mobile Numbers List</h4>
						 <?php
                                                 foreach ($mobiles as $mobile):
                                                     echo $mobile['mobile'].';<br>';
                                                 endforeach;
                                                 
                                                 ?>          
					</div>
			
				</div><!--/span-->
                                
			</div><!--/row-->