<div class="eight_new01 columns">

    <div class="bodywrapper">
        <form action="<?=  site_url('admin/order_save').'/'.$product['productId']?>" method="post" >

            <div class="row">
                <?php if($this->session->userdata('msg')){ ?>
                <div class="label  label-danger text-center">
                    <strong class="pull-right" style="font-size: 22px">  <?=$this->session->userdata('msg')?>
                        <?php $this->session->unset_userdata('msg');?></strong>
                </div>
                <?php } ?>
                <div class="twelve column detail_heading text-right"><strong><?=$product['productTitle']?></strong><span>
                    <div class="price-box">
                        <span class="regular-price" id="product-price-2738">
                            <span class="price">Rs. <?=$product['price']?></span> </span>
                    </div>
                    </span></div>
            </div>
            <div class="row">
                <div class="six columns padd_0">



                    <div class="big_thumb">
                        <a href="<?=site_url('assets/products_thumbs/').'/'.$product['thumb']?>" rel="lightboxclone" class="" title="E-Islamic Shop | <?=$product['productTitle']?>"><img src="<?=site_url('assets/products_thumbs/').'/'.$product['thumb']?>" alt="E-Islamic Shop | <?=$product['productTitle']?>" ></a>
                    </div>

                </div>
                <div class="six columns padd">
                    <p class="breadcrumbs text-right" >
                        <?=$product['productTitle']?> </p>
                    <span class="text-right"><?=$product['specs']?></span>
                    <!--<strong>Publisher: </strong><span><a href="/catalogsearch/advanced/result/?publisher=IIPH">IIPH</a></span>-->
                    </p>
                <script>
                    var a = 1;
                    function increase(){
                        var textBox = document.getElementById("qty");
                        a=textBox.value;
                        if(a>=1){
                            a++;
                            textBox.value = a;
                        }
                    }  
                    function decrease(){
                        var textBox = document.getElementById("qty");
                        if(a>1){
                            a--;
                            textBox.value = a;
                        }
                    }  
                </script>
                <p class="qty">
                    <span>
                        <div class="">
                            <div class="col-xs-3" style="margin-left:-15px;">
                                <div class="form-group">
                                    <input type="text" class="form-control" style="" name="quantity" id="qty" value="1" title="Qty">
                                </div>
                            </div>
                            <div class="col-xs-9">
                                <span class="pull-right" style="margin-bottom:10px;margin-top:-5px;margin-right:-27px;">
                                    عدد<br>
                                    <img src="http://darussalam.com/skin/frontend/darutheme/default/images/plus.jpg" onclick="increase()" alt="increase" border="0"><br>
                                    <img src="http://darussalam.com/skin/frontend/darutheme/default/images/less.jpg" onclick="decrease()" alt="decrease" border="0">
                                </span>
                            </div>

                        </div>
                    </span>
                    <style>
                        .inp{
                            font-family: 'Jameel Noori Nastaleeq' !important;
                            padding: 5px 15px;
                            color: white;
                            margin: 5px 0px 5px 0px;
                            border-radius:5px;
                            border:0px;
                            font-weight: bold;
                        }

                    </style>
                <div class="form-group">
                    <input class="btn-info inp form-control" style="" type="submit" title="Add to Cart"  value="آرڈر کریں" >
                </div>
                <div class="form-group">
                    <input class="form-control" style="margin-bottom:5px" type="text" name="name"  placeholder="Name" required="">
                </div> 
                <div class="form-group">
                    <input class="form-control" style="margin-bottom:5px" type="text" name="contact" placeholder="Contact" required="">
                </div>   
                <div class="form-group"> 
                    <textarea class="form-control" style="margin:0px 0px 5px 0px" name="address" placeholder="Address" required=""></textarea>
                </div>
                <script>

                    function OUTOFSTOCK(){

                        if(document.getElementById("qty").value > 100.0000)
                        {
                            alert("call us at 0044(0) 208 539 4885");
                            return false;
                        }
                        return true;


                    }
                </script>
                </p>
            <div class="clearer"></div>

            </div>
    </div>
    <div class="row"><div class="twelve column padd">
        <!--<ul class="tabs">
<li class="active licl" id="tab1"><a href="javascript:void(0);" onclick="showHide(1)">Description</a></li>
<li id="tab2" class="licl"><a href="javascript:void(0);" onclick="showHide(2)">Reviews</a></li>
</ul>-->
        <div class="tabs-content" id="tabcon1" style="display:block;">
            <h2>Product  Description</h2>
            <!--<h3><?=$product['productTitle']?></h3><br>-->
            <div align="justify">
                <?=$product['description']?>
                <br>
            </div><br>
        </div>

        </div></div></form>

<div class="row">
    <div class="twelve column relative padd">
        <h2>Related Products</h2>
        <div class="row">
            <div class="twelve columns flexslider1">

                <script type="text/javascript">decorateList('block-related', 'none-recursive')</script>
                <div class="flex-viewport" style="overflow: hidden; position: relative;"><ul class="slides" style="width: 2200%; transition-duration: 0.6s; transform: translate3d(0px, 0px, 0px);">
                    <?php $products=$this->admin_model->get_products_by_cat($product['catId']); 
                    foreach ($products as $sproduct):
                    ?> 
                    <li style="width: 216px; float: left; display: block;">

                        <p class="related_img"><a href="<?=site_url("home/product_details/$sproduct->productId")?>" title="E-Islamic Shop | <?=$sproduct->productTitle?>" class="product-image"><img src="<?=site_url("assets/products_thumbs/$sproduct->thumb")?>" alt="E-Islamic Shop | <?=$sproduct->productTitle?>"></a></p>
                        <p class="related_price"><strong>
                            </strong></p><div class="price-box"><strong>
                        <span class="regular-price" id="product-price-2721-related">
                            <span class="price">Rs. <?=$sproduct->price?></span> </span>
                        </strong></div><strong>
                        </strong><p></p>
                        <p class="related_name"><?=$sproduct->description?></p>

                    </li>
                    <?php endforeach; ?>
                    </ul></div>
                <ul class="flex-direction-nav"><li><a class="flex-prev" href="#">Previous</a></li><li><a class="flex-next" href="#">Next</a></li></ul>
            </div>
        </div>

        <script defer="" src="http://darussalam.com/skin/frontend/darutheme/default/js/jquery.flexslider.js"></script>
        <script type="text/javascript">

            jQuery(window).load(function(){
                jQuery('.flexslider1').flexslider({
                    animation: "slide",
                    animationLoop: true,
                    controlNav: false,
                    itemWidth: 216,
                    //itemMargin: 5,
                    minItems: 2,
                    maxItems: 6,
                    start: function(slider){
                        jQuery('body').removeClass('loading');
                    }
                });
            });
        </script>
    </div>
</div>
<link rel="stylesheet" href="http://darussalam.com/skin/frontend/darutheme/default/css/flexslider.css" type="text/css" media="screen">
<script defer="" src="http://darussalam.com/skin/frontend/darutheme/default/js/jquery.flexslider.js"></script>
<script type="text/javascript">

    jQuery(window).load(function(){
        jQuery('.flexslider').flexslider({
            animation: "slide",
            animationLoop: true,
            controlNav: false,
            itemWidth: 216,
            //itemMargin: 5,
            minItems: 2,
            maxItems: 6,
            start: function(slider){
                jQuery('body').removeClass('loading');
            }
        });
    });
</script>

<script src="http://darussalam.com/skin/frontend/darutheme/default/js/common.js"></script>

<script type="text/javascript">
    var lifetime = 186000;
    var expireAt = Mage.Cookies.expires;
    if (lifetime > 0) {
        expireAt = new Date();
        expireAt.setTime(expireAt.getTime() + lifetime * 1000);
    }
    Mage.Cookies.set('external_no_cache', 1, expireAt);
</script>
</div> </div>