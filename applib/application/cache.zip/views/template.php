<?php

    $this->load->view('header');
    $this->load->view($page);
    $this->load->view('footer');