<?php             $sections=$this->admin_model->get_sections(); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

    <meta http-equiv="content-type" content="text/html;charset=UTF-8" />
    <head>
        <meta http-equiv="X-UA-Compatible" content="IE=9,chrome=1">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <!--<script src='../www.google.com/recaptcha/api.js'></script>-->
        <meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
        <title>E Islamic Shop</title>
        <!-- Fonts -->

        <!--<style>
@font-face
{
font-family: 'Jameel Noori Nastaleeq';
src: url('http://www.eislamicshop.com//quranic.ttf');	
src: url('http://www.eislamicshop.com/quranic.ttf') format('truetype');	
}

@font-face
{
font-family: sinkin;
src: url('http://www.eislamicshop.com/SinkinSans-400Regular.otf');	
src: url('http://www.eislamicshop.com/SinkinSans-400Regular.otf') format('OpenType Format');	
}
</style>-->
        <!--end of fonts--> 
        <meta name="description" Content="Darussalam Is Offering sppecial offer for Coming Ramadhan only for Face Book Subscribers for World Wide Customers.Flat shipping Available for hundreds of books and other Muslim Products.Buy with Confident 100% Money Back Gaurantee..."/>
        <meta name="keywords" content="Ramadan Special by Darussalam, dates, ramadan, madjoul dates, darussalam, islamic boks on ramadan, umarah, fasting, fast according to Quran and Sunnah, zakah calculation book"/>
        <meta name="robots" content="INDEX,FOLLOW"/>
        <link rel="icon" href="media/favicon/default/darussalamLogo.gif" type="image/x-icon"/>
        <link rel="shortcut icon" href="media/favicon/default/darussalamLogo.gif" type="image/x-icon"/>
        <!--[if lt IE 7]>
<script type="text/javascript">
//<![CDATA[
var BLANK_URL = 'http://darussalam.com/js/blank.html';
var BLANK_IMG = 'http://darussalam.com/js/spacer.gif';
//]]>
</script>
<![endif]-->
        <link rel="stylesheet" type="text/css" href="<?=site_url('assets/css/bootstrap.css')?>"/>
        <link rel="stylesheet" type="text/css" href="<?=site_url('assets/css/foundation.min.css')?>"/>

        <link rel="stylesheet" type="text/css" href="<?=site_url('assets/ddmenu.css')?>"/>
        <link rel="stylesheet" type="text/css" href="<?=site_url('assets/css/darussalam-style.css')?>" />
        <link rel="stylesheet" type="text/css" href="<?=site_url('assets/css/darussalam.css')?>" />
        <!--<link rel="stylesheet" type="text/css" href="<?=site_url('assets/css/elastislide.css')?>" media="all"/>-->
        <!--<link rel="stylesheet" type="text/css" href="<?=site_url('assets/css/widgets.css')?>" media="all"/>-->
        <!--<link rel="stylesheet" type="text/css" href="<?=site_url('assets/ip_sitemaphtml/style.css')?>" media="all"/>-->
        <!--<link rel="stylesheet" type="text/css" href="<?=site_url('assets/magazento/easytopseller/style.css')?>" media="all"/>-->
        <!--<link rel="stylesheet" type="text/css" href="<?=site_url('assets/default/css/print.css')?>" media="print"/>-->
        <!--<script type="text/javascript" src="<?=site_url('assets/js/prototype/prototype.js')?>"></script>
<script type="text/javascript" src="<?=site_url('assets/js/lib/ccard.js')?>"></script>
<script type="text/javascript" src="<?=site_url('assets/js/prototype/validation.js')?>"></script>
<script type="text/javascript" src="<?=site_url('assets/js/scriptaculous/builder.js')?>"></script>
<script type="text/javascript" src="<?=site_url('assets/js/scriptaculous/effects.js')?>"></script>
<script type="text/javascript" src="<?=site_url('assets/js/scriptaculous/dragdrop.js')?>"></script>
<script type="text/javascript" src="<?=site_url('assets/js/scriptaculous/controls.js')?>"></script>
<script type="text/javascript" src="<?=site_url('assets/js/scriptaculous/slider.js')?>"></script>
<script type="text/javascript" src="<?=site_url('assets/js/varien/js.js')?>"></script>
<script type="text/javascript" src="<?=site_url('assets/js/varien/form.js')?>"></script>
<script type="text/javascript" src="<?=site_url('assets/js/varien/menu.js')?>"></script>
<script type="text/javascript" src="<?=site_url('assets/js/mage/translate.js')?>"></script>
<script type="text/javascript" src="<?=site_url('assets/js/mage/cookies.js')?>"></script>-->
        <script type="text/javascript" src="<?=site_url('assets/js/darujs/jquery.js')?>"></script>
        <!--<script type="text/javascript" src="<?=site_url('assets/js/darujs/modernizr.custom.17475.js')?>"></script>-->
        <!--<link href="rss/catalog/new/store_id/3/index.html" title="New Products" rel="alternate" type="application/rss+xml"/>-->
        <!--<link href="rss/catalog/special/store_id/3/cid/0/index.html" title="Special Products" rel="alternate" type="application/rss+xml"/>-->
        <!--<link rel="canonical" href="ramadan-special.html"/>-->
        <!--<link href="rss/catalog/category/cid/47/store_id/3/index.html" title="رمضان الخاصة RSS Feed" rel="alternate" type="application/rss+xml"/>-->
        <!--[if lt IE 7]>
<script type="text/javascript" src="http://darussalam.com/js/lib/ds-sleight.js"></script>
<script type="text/javascript" src="http://darussalam.com/skin/frontend/base/default/js/ie6.js"></script>
<![endif]-->

        <!--<script type="text/javascript" src="../acp-magento.appspot.com/js/acp-magento66e0.js?v=2&amp;store=3&amp;UUID=ag1zfmFjcC1tYWdlbnRvchoLEg1BTV9TaXRlX0dyb3VwGICAgIiGwe4LDA&amp;product_url=&amp;product_sku="></script>--> 

        <!--<script type="text/javascript">//<![CDATA[
var Translator = new Translate([]);
//]]></script>-->

        <!--<script src="<?=site_url('assets/js/darujs/modernizr.foundation.js')?>"></script>-->
        <!--<script src="<?=site_url('assets/js/darujs/accordian.js')?>" type="text/javascript"></script>-->
        <script src="<?=site_url('assets/ddmenu.js')?>" type="text/javascript"></script>
        <style>
            #ddmenu .dropdown{
                background: white
            }
        </style>

    </head>
    <style>
        body { font-family: 'Jameel Noori Nastaleeq' !important; font-size: 15px } #content h1, h2, h3, h4, h5, h6 { font-family: 'Jameel Noori Nastaleeq' !important;}
    </style>

    <script type="text/javascript" src="<?=site_url('font/fontsmoothie.min.js')?>" async></script>
    <style>
        /* INFO We recommend to use @import or the link tag to include the
        font-face definition into your page.
        NOTE Some browsers block access to CSS rules in external files if the
        page is not loaded via HTTP. Therefore the Font Smoothie script
        will not work if you open this page as a local file. */
        @import url('<?=site_url('font/JameelNooriNastaleeq-Regular.css')?>');

        /* INFO Just some other styles to beautify the page ;) */
    </style>
    <body style="background-image: url('http://localhost/e_islamic/assets/bg.jpg');">



        <div id="topsection">
            <div class="row" style="position:relative;">
                <div class="five columns text-right mob_center">
                    <ul class="toplinks left">
                        <li class="gplus"><g:plusone></g:plusone></li>

                        <li style="border-right:none;font-size: 20px">Call us: <strong>(091) : 2 5 8 0 3 2 5 / 2 5 9 0 3 1 5</strong></li>

                    </ul>

                </div>
                

                <div class="three columns topsocial">
                    <ul><li><a href="#" target="_blank"><img src="<?=site_url('assets/images/facebook.png')?>" width="22" height="22" alt="facebook" title="Facebook"></a></li>
                        <!--<li><a href="https://twitter.com/Darusalambooks" target="_blank"><img src="skin/frontend/darutheme/default/images/twitter.png" width="22" height="22" alt="twitter" title="Twitter"></a></li><li><a href="http://www.youtube.com/channel/UCvm8tTL8STfroBTw0-lfoTw" target="_blank"><img src="skin/frontend/darutheme/default/images/tube.png" width="22" height="22" alt="tube"></a></li>-->
                    </ul>
                    <br><br>
                            <form action="<?=site_url('home/search')?>" method="post">
                    <div class=" form-group" style="margin-top:10px">
                        <div class="input-group">
                            <input type="text"  name="search"class="form-control" placeholder="Search for...">
                                <span class="input-group-btn">
                                    <button class="btn btn-secondary" type="submit">Search</button>
                                </span>
                              </div>
                                </div></form>
                </div>

                <div class="four columns">
                    <h1 class="logo"><a href="<?=  site_url()?>"></a></h1>
                </div>


                

            </div>
            <!--<div class="row">
<div class="navigation">
<div class="nav_rgt">
<div class="twelve columns">
<ul class="special_tab right">
<li><a href="<?=  site_url()?>" title="Home">Home</a></li> 
<?php 
    $main_menus=$this->base_model->get_main_menus('*');
              foreach($main_menus as $main_menu): 
?> 
<li><a href="<?=  site_url("home/pages/$main_menu->mmId")?>" title="<?=$main_menu->name?>"><?=$main_menu->name?></a></li> 

<?php endforeach; ?>
</ul>
</div>
</div>
</div>
</div>-->
            <nav id="ddmenu" style="font-family:'jameel noori nastaleeq'">

                <ul>
                    <li class="no-sub"><a class="top-heading" href="<?=site_url()?>">Home</a></li>
                    <li class="full-width">
                        <span class="top-heading">Al-Ilm Book Series</span>
                        <i class="caret"></i>
                        <div class="dropdown">
                            <div class="dd-inner">
                                <ul class="column">
                                    <?php $i=1;$cats=$this->admin_model->get_cats_by_section2(6);
                                          foreach($cats as $cat):
                                    ?>  
                                    <li><a href="<?=  site_url("home/products/$cat->catId")?>"><?=$cat->name?></a></li>

                                    <?php  

    if($i==4)
    {
        echo '</ul><ul class="column">';
        $i=0;
    }
                                           $i++;
                                           endforeach; ?>
                                </ul> 
                            </div>
                        </div>
                    </li>
                    <?php 
                    $main_menus=$this->base_model->get_main_menus('*');
                    foreach($main_menus as $main_menu): 
                    ?> 
                    <li class="no-sub"><a class="top-heading" href="<?=  site_url("home/pages/$main_menu->mmId")?>"><?=$main_menu->name?></a></li>
                    <?php endforeach; ?>


                </ul>
            </nav>
        </div>
        <script>
            jQuery(document).ready(function(){
                //	$( "#clickme" ).click(function() {
                //		$( "#book" ).toggle( "slow", function() {
                //		// Animation complete.
                //		});
                //	});	
            });
            jQuery('.dropmargin0 ul li ul').hide();
            jQuery('.dropmargin0 ul li a').click(function () {
                // jQuery(this).toggleClass('down_arrow');
                var currentLink = jQuery(this).attr('rel');
                jQuery(currentLink).slideToggle();
            });
        </script>
        <script>




            jQuery(".leftmenu h2").click(function () { 
                jQuery(".leftmenu ul").hide();
            });

            jQuery(document).ready(function(){
                setTimeout('jQuery("p.empty").hide();',5000);
            });

        </script>
        <!--<script>
jQuery("#plus").click(function(){
jQuery(".catbox").toggle();
jQuery(this).toggleClass('iconless');
});

</script>-->
        <div class="row" style="background-color: #fff">
            <div class="two_new01 columns hide_mobile">
                <div class="leftmenu">
                    <h2>التصنيفات</h2>
                    <ul class="navmenu">
                        <?php foreach($sections as $section): if($section->secId!=6):?>   
                        <li>
                            <a href="#"><b>
                                <?=$section->name?></b> </a>
                        </li>
                        <ul id="tab5">
                            <?php $cats=$this->admin_model->get_cats_by_section($section->secId);
                                foreach($cats as $cat):
                            ?>  
                            <li>
                                <a class="icon14 nav-top-item " href="<?=site_url("home/products/$cat->catId")?>"> <?=$cat->name?></a>
                            </li>
                            <?php  endforeach; ?>
                        </ul>
                        <?php endif;endforeach; ?>
                    </ul>
                    <br>
                        <br>
                            <a href="<?=site_url('home/pages/6')?>"><img src="<?=  site_url('assets/order.png')?>"></a>
                </div>

                <!--<div class="giftoff">
<p><img src="<?=site_url('assets/images/save_30_gift.png')?>" alt="save and gift"/></p>
</div>
<div id="messages_product_view">
</div>-->

            </div>
            

