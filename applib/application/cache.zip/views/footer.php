<?php             $ads=$this->admin_model->get_ads(); ?>

<div class="two_new01 columns ">
<!--<div class="block block-cart">
<div class="block-title">
<strong><span>My Cart</span></strong>
</div>
<div class="block-content">
<p class="empty" style="display: none;">You have no items in your shopping cart.</p>
</div>
</div>-->
<div class="adveties">
    <div id="fb-root">
        <br>
             <br>
        <label>Subscribe for Updates</label>
        <form action="<?=site_url("home/email_subscribe?url=".$this->router->class.'/'.$this->router->method.'/'.$this->uri->segment(3))?>" method="post">
        <div class="input-group">
            
            
            <input type="text"  name="email"class="form-control" placeholder="Email Address">
            
            <span class="input-group-btn">
                <button class="btn btn-secondary" type="submit">Submit</button>
            </span>
          </div>
          </form>
            <br><br>
             <label>Subscribe for SMS Updates</label>
             <form action="<?=site_url('home/mobile_subscribe?url='.$this->router->class.'/'.$this->router->method.'/'.$this->uri->segment(3))?>" method="post">
             <div class="input-group">
            
           
            <input type="text"  name="mobile"class="form-control" placeholder="Mobile Number">
            <span class="input-group-btn">
                <button class="btn btn-secondary" type="submit">Submit</button>
            </span>
          </div>
        </form>
             <br>
             <br>
        <?php foreach($ads as $ad): ?>
        
        <a href="<?=$ad->link?>" target="_blank">
            <img class="ads" src="<?=site_url("assets/ads_thumbs/$ad->ad")?>" alt=""></a> 
         <?php endforeach;?> 
    </div>
</div>
<!--<div class="latest_product">
<h2>Latest product</h2>
<div class="lft_sec"><a href="russian-al-qur-an-al-kareem.html" title="Russian: Al-Qur'an Al-Kareem"><img src="media/catalog/product/cache/1/small_image/90x136/9df78eab33525d08d6e5fb8d27136e95/i/m/image_3__5.jpg" alt="Russian: Al-Qur'an Al-Kareem"></a></div>
<div class="rgt_sec"><p><a href="russian-al-qur-an-al-kareem.html" title="Russian: Al-Qur'an Al-Kareem">Russian: Al-Qur'an Al-Kareem</a></p>
<p class="lat_price"><span class="price">£17.00</span></p>
<p><a href="checkout/cart/add/uenc/aHR0cDovL2RhcnVzc2FsYW0uY29tLw%2c%2c/product/2740/form_key/AfKpzae68MCW6nNr/index.html"><img src="skin/frontend/darutheme/default/images/buy.png" alt="buy" border="0"></a></p>
</div>
 
</div>-->
</div>
</div>
<div class="footer_wrapper">

</div>

<div class="bot_wrapper"><div class="row">
<div class="nine columns">
    <ul class="bot_nav" style="font-size: 18px">
        <li  style=" text-transform: lowercase">+923334532836   &nbsp;&nbsp;&nbsp; +92-91-2580325  &nbsp;&nbsp;&nbsp;  +92-91-2590315 <br>www.alishaat.com   ishaatacademy@gmail.com</li>

</ul>
</div>
<div class="three columns copyright"> عبدالغنی پلازہ محلہ جنگی قصہ خوانی پشاور</div>
</div></div>
<div class="bot_blank_gray"></div>
 
<!--<script src="<?=site_url('assets/js/darujs/app.js')?>"></script>-->
 
<!--<script src="<?=site_url('assets/js/darujs/jquery.elastislide.js')?>"></script>-->
<!--<script src="<?=site_url('assets/js/darujs/jquerypp.custom.js')?>"></script>-->
 
<!--<script type="text/javascript">
  jQuery( '#carousel' ).elastislide();
</script>-->
  </body>

</html>
<script type="text/javascript">
window.onload= function(){
parent.window.scrollTo(0,0);
}
</script>
