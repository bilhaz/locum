<style>
    .list-dashed > article{
        border-bottom: 1px dashed #5f5f5f !important;
    }
</style>
<section class="inner-header divider layer-overlay overlay-dark" data-bg-img="images/bg/bg2.jpg">
      <div class="container pt-30 pb-30">
        <!-- Section Content -->
        <div class="section-content text-center">
          <div class="row"> 
            <div class="col-md-6 col-md-offset-3 text-center">
                <br>
                <br>
              <h2 class="text-theme-colored font-36">Activities Details</h2>
              <ol class="breadcrumb text-center mt-10 white">
                <li><a href="#">Home</a></li>
                <li><a href="#">Pages</a></li>
                <li class="active">Activities</li>
              </ol>
            </div>
          </div>
        </div>
      </div>      
    </section>
    
    <section>
      <div class="container mt-30 mb-30 pt-30 pb-30">
        <?php foreach($activities as $activity): ?>
          <div class="row ">
            <div class="blog-posts">
              <div class="col-md-12">
                <div class="row list-dashed">
                  
                  <article class="post clearfix mb-50 pb-30">
                       <div class="item">
                    <img src="<?=site_url("assets/activities_thumbs/$activity->actThumb")?>?>" alt="<?=$activity->actTitle.' ('.$activity->actYear,')'?> Thumbnail">
                    <h4 class="title"><?=$activity->actTitle.' ('.$activity->actYear,')'?></h4>
                    <p><?=$activity->actDescription?></p>
                  </div>
                    <div class="entry-header">
                        <!--<h5 class="entry-title"><a href="#"> </a></h5>-->
                      <ul class="list-inline font-12 mb-20 mt-10">
                        <li>Donee <a class="text-theme-colored"><?=$activity->actDonee?> |</a></li>
                        <li>Participants <a class="text-theme-colored"><?=$activity->actParticipant?> |</a></li>
                        <li>Expense <a class="text-theme-colored"><?=$activity->actExpense?> |</a></li>
                        <li>Start Date <a class="text-theme-colored"><?=date('d/m/Y',  strtotime($activity->actStartDate));?> |</a></li>
                        <li>End Date <a class="text-theme-colored"><?=date('d/m/Y',  strtotime($activity->actEndDate));?> |</a></li>
                        <li>Place <a class="text-theme-colored"><?=$activity->actPlace?> |</a></li>
                      </ul>
<!--                         <div class="entry-content col-xs-12">
                             <div class="col-xs-12" style="word-wrap: normal"></div>
                      
                    </div>-->
                      <div class="post-thumb">
                          <p style="text-decoration:underline"><b>Activity Gallery</b></p>
                        <!-- Portfolio Gallery Grid -->
                        <div class="portfolio-gallery grid-5 masonry gutter-small clearfix" data-lightbox="gallery">
                             <?php

//                                     $dir = getcwd().'/assets/activities/'.$activity->folderName.'/'.$activity->actYear.'/';
                                      $imgs=$this->base_model->get_pictures($activity->actId);
                                      if($imgs==false){
                                          ?>
                             <div class="portfolio-item">
                                                        <p style="color:red">No Image Found for this activity</p>
                                                      </div>
                            <?php
                                        }
                                      else {
                                        foreach($imgs as $img):

                                                      ?>		
                                                     <!-- Portfolio Item Start -->
                                                     <div class="portfolio-item">
                                                        <a href="<?php echo site_url("/assets/activities/$activity->folderName/$activity->actYear/$img");?>" data-lightbox="gallery-item" title="<?=$activity->actTitle?>"><img style="min-height:150px;max-height:150px;min-width: 100%" src="<?php echo site_url("/assets/activities/$activity->folderName/$activity->actYear"."_thumbs/$img");?>" alt=""></a>
                                                      </div>
                                                      <!-- Portfolio Item End -->

                                                <?php														
                                         endforeach;}
                                      	
                                   ?>

                        </div>
                      </div>
                      
                    </div>
<!--                    <div class="entry-content">
                      <ul class="list-inline like-comment pull-left font-12">
                        <li><i class="pe-7s-comment"></i>36</li>
                        <li><i class="pe-7s-like2"></i>125</li>
                      </ul>
                      <a class="pull-right text-gray font-13" href="#"><i class="fa fa-angle-double-right text-theme-colored"></i> Read more</a>
                    </div>-->
                  </article>
                  
                  
                </div>
              </div>
<!--              <div class="col-md-12">
                <nav>
                  <ul class="pagination theme-colored">
                    <li> <a aria-label="Previous" href="#"> <span aria-hidden="true">«</span> </a> </li>
                    <li class="active"><a href="#">1</a></li>
                    <li><a href="#">2</a></li>
                    <li><a href="#">3</a></li>
                    <li><a href="#">4</a></li>
                    <li><a href="#">5</a></li>
                    <li><a href="#">...</a></li>
                    <li> <a aria-label="Next" href="#"> <span aria-hidden="true">»</span> </a> </li>
                  </ul>
                </nav>
              </div>-->
            </div>
            
<!-- side         <div class="col-sm-12 col-md-3">
            <div class="sidebar sidebar-left mt-sm-30">
              <div class="widget">
                <h5 class="widget-title line-bottom">Archives</h5>
                <ul class="list-divider list-border">
                  <li><a href="#"><i class="fa fa-check-square-o mr-10 text-black-light"></i> Vehicle Accidents</a></li>
                  <li><a href="#"><i class="fa fa-check-square-o mr-10 text-black-light"></i> Family Law</a></li>
                  <li><a href="#"><i class="fa fa-check-square-o mr-10 text-black-light"></i> Personal Injury</a></li>
                  <li><a href="#"><i class="fa fa-check-square-o mr-10 text-black-light"></i> Personal Injury</a></li>
                  <li><a href="#"><i class="fa fa-check-square-o mr-10 text-black-light"></i> Case Investigation</a></li>
                  <li><a href="#"><i class="fa fa-check-square-o mr-10 text-black-light"></i> Business Taxation</a></li>
                </ul>
              </div>
              <div class="widget">
                <h5 class="widget-title line-bottom">Twitter Feed</h5>
                <div class="twitter-feed list-border clearfix" data-username="Envato"></div>
              </div>
              <div class="widget">
                <h5 class="widget-title line-bottom">Image gallery with text</h5>
                <div class="widget-image-carousel">
                  <div class="item">
                    <img src="https://placehold.it/365x230" alt="">
                    <h4 class="title">This is a Demo Title</h4>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae illum amet illo.</p>
                  </div>
                  <div class="item">
                    <img src="https://placehold.it/365x230" alt="">
                    <h4 class="title">This is a Demo Title</h4>
                    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Molestiae illum amet illo.</p>
                  </div>
                    <?php $events=$this->base_model->get_events(); 
                    foreach($events as $event):
                ?>
                <li><a style="color:black;border-bottom: 1px solid grey" class="tree-toggler nav-header"><?=$event->eventName?> <i class="fa fa-angle-down"></i></a>
                  <ul class="nav nav-list tree">
                      <?php $years=$this->base_model->get_activities_years($event->eventId); 
                               if($years==null){ echo '<p style="color:red">No Activity Found</p>';}else{
                                foreach($years as $year): ?>
                      <li><a href="<?=  site_url("home/activity_list/$event->eventId/$year->actYear/")?>"><?=$year->actYear?></a></li>
                               <?php endforeach; }?>
                  </ul>
                </li>
                
                <?php endforeach; ?>
-->              <!--
                </div>
              </div>
              <div class="widget">
                <h5 class="widget-title line-bottom">Tags</h5>
                <div class="tags">
                  <a href="#">travel</a>
                  <a href="#">blog</a>
                  <a href="#">lifestyle</a>
                  <a href="#">feature</a>
                  <a href="#">mountain</a>
                  <a href="#">design</a>
                  <a href="#">restaurant</a>
                  <a href="#">journey</a>
                  <a href="#">classic</a>
                  <a href="#">sunset</a>
                </div>
              </div>
            </div>
          </div>-->
        </div>
            <?php endforeach;?>
      </div>
    </section>
