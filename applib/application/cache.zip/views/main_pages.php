<div class="eight_new01 columns" style=" padding: 15px">
    <center><h2><?=$pages['name']?></h2></center><hr>
              <?=$pages['content']?>
</div>
      
