<div class="eight_new01 columns">
 
<div class="bodywrapper">
<div class="body_headding">
    <h1 style="text-align: right"><?=$catName?></h1>
</div>


<div class="clearfix"></div>
<script>
	jQuery(document).ready(function(){
		jQuery('.sorting').click(function(){
			jQuery('.sortbox').toggle('slow');
		});
	});
</script>
<div class="row">
    <?php 
    $num=0;
    foreach($products as $product):?>
<div class="prod_four columns margin0">
<p class="prod_img">
<a href="<?=site_url("home/product_details/$product->productId")?>" title="<?=site_url("$product->productTitle")?>"><img src="<?=site_url("assets/products_thumbs/$product->thumb")?>" width="170" height="170" alt="<?=site_url("$product->productTitle")?>"></a>
</p>
 
<p class="prod_name">
<a href="<?=site_url("home/product_details/$product->productId")?>" style="color:#797979; float: right;font-size: 18px"><?=$product->productTitle?></a>
</p>
 
<p class="price">
</p><div class="price-box">
<span class="regular-price" id="product-price-2506">
<span class="price">Rs.<?=$product->price?></span> </span>
</div>
<p></p>
<!--<button type="button" title="Add to Cart" class="button btn-cart" onclick="setLocation('http://darussalam.com/checkout/cart/add/uenc/aHR0cDovL2RhcnVzc2FsYW0uY29tL2hhamotc2hvcC13aXRoLWZhc3QtZGVsaXZlcnkuaHRtbA,,/product/2506/form_key/AfKpzae68MCW6nNr/')"><span><span>Add to Cart</span></span></button>-->
 
</div>
    <?php
    $num++;
    if($num==3){
        echo '</div><div class="row">';
    }
    endforeach; ?>
</div>

<script type="text/javascript">decorateGeneric($$('ul.products-grid'), ['odd','even','first','last'])</script>
<div class="toolbar-bottom">
<!--<div class="row pagging">
<div class="limiter" style="width:30%; float:left;">
<label>Show</label>
<div class="dd_sec"><select onchange="setLocation(this.value)">
<option value="http://darussalam.com/hajj-shop-with-fast-delivery.html?limit=12" selected="selected">
12 </option>
<option value="hajj-shop-with-fast-delivery6d6f.html?limit=48">
48 </option>
<option value="hajj-shop-with-fast-delivery8ef8.html?limit=96">
96 </option>
<option value="hajj-shop-with-fast-delivery0e5a.html?limit=all">
All </option>
</select></div> per page </div>
<div style="width:70%; float:right;">
<div class="four columns">
<div class="pager_lnline">
<span>Page:</span>
<strong>1 of 2</strong>
<a href="hajj-shop-with-fast-deliverycff1.html?p=1">
<img src="skin/frontend/darutheme/default/images/pagging_nxt.jpg" width="23" height="30" alt="pagging next">
</a>
<a href="hajj-shop-with-fast-delivery905b.html?p=2">
<img src="skin/frontend/darutheme/default/images/pagging_prv.jpg" alt="pagging previous">
</a>
</div>
</div>
<div class="eight columns mob_pad">
<div class="pager_lnline">
<form method="get" action="http://darussalam.com/hajj-shop-with-fast-delivery.html?p=0" id="pager_page_specify_form">
<span style="line-height:30px; float:left;">Jump to page:</span> <input name="p" id="p" type="text" value="1" style="float:left; height:30px; line-height:30px;"><input name="go" type="image" src="skin/frontend/darutheme/default/images/jump_btn.jpg" onclick="pagerPageSpecifyForm.submit(this)">
</form>
</div>
</div>
 
</div>
</div>-->
</div>
</div> </div>