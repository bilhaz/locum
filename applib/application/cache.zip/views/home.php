<div class="eight_new01 columns">
<div class="std"><p><span style="color: #ffffff;">Darussalam&nbsp;</span></p></div>

<div class="flexslider">
<ul class="slides">
    <?php foreach($slides as $slide): ?>
        <li>
            <a href="<?=$slide->link?>">
            <img src="<?=site_url("assets/slides_thumbs/$slide->slide")?>" alt="DarussalamBanner.jpg">
            </a>
        </li>
       <?php endforeach;?> 
</ul>
</div>
<script src="<?=site_url('assets/js/jquery-1.9.1.js')?>"></script>
<script defer="" src="<?=site_url('assets/js/jquery.flexslider.js')?>"></script>
<script type="text/javascript">

//  jQuery.noConflict();
//
//    jQuery(function(){
//
//      SyntaxHighlighter.all();
//
//    });

    jQuery(window).load(function(){

      jQuery('.flexslider').flexslider({

        animation: "slide",

		slideshowSpeed: 20000,

        start: function(slider){
			flexslider = slider; //Initializing flexslider here.
            jQuery('body').removeClass('loading');

        }

      });

    });

  </script>
<div class="new_prod">
<div id="sub-cats">
    <?php foreach($sections as $section): ?>
    <br>
<ul class="homecat">
    <?php 
        $cats=$this->admin_model->get_cats_by_section($section->secId);
        foreach($cats as $cat):
        ?>
    <li class="margin0"><a  href="<?=site_url("home/products/$cat->catId")?>" target="_self"><img alt="Qurans" src="<?=site_url("assets/cats_thumbs/$cat->thumb")?>"></a><span><a href="<?=site_url("home/products/$cat->catId")?>" style="direction:RTL;"><?=$cat->name?></a></span></li>
    <?php endforeach;?>
</ul> 
    <br><hr>
    <?php endforeach; ?>
</div>
</div>
  <?php   foreach($sections as $section): ?>
<div class="bestseller1 left">
<h2><span>New Products</span></h2>
 
<ul>
    <?php  
            $products=$this->admin_model->get_products_by_section($section->secId);
            foreach($products as $product):
        ?>
        <li>
            <div class="lft_sec left"><a href="<?=site_url("home/product_details/$product->productId")?>" title="<?=$product->productTitle?>"><img width="110px" alt="<?=$product->productTitle?>" src="<?=  site_url("assets/products_thumbs/$product->thumb")?>"></a></div>
        <div class="rgt_sec left">
        <p class="bestname"><a href="<?=site_url("home/product_details/$product->productId")?>" style="color:#797979; font-size: 18px; float: right;direction:RTL;" title="<?=$product->productTitle?>"><?=$product->productTitle?></a></p><a href="<?=site_url("home/product_details/$product->productId")?>" style="color:#797979;" title="<?=$product->productTitle?>">
        <p class="lat_price"><span style="float:left; display: block;">
        </span></p><div class="price-box">
        <span class="regular-price" id="product-price-2737">
        <span class="price">Rs.<?=$product->price?></span> </span>
        </div>

        </a>
        <a href="<?=site_url("home/product_details/$product->productId")?>" style="float: right; padding-top: 4px;"><img border="0" alt="buy" src="assets/images/buy.png"></a><p></p>
        </div>
        </li>
    <?php endforeach; ?>
        <!--<a href="specials.html">View More</a>-->
</ul>
</div>
  <?php endforeach; ?>
<!--<div class="bestseller left">
<h2>BESTSELLER<span>Check out some of the hottest books!</span>
</h2>
<ul>
<li>
<div class="lft_sec left"><a href="a-brief-illustrated-guide-to-understanding-islam-ang-maikling-paglalarawan-ng-gabay-sa-pag-unawa-sa-islam.html" title="A Brief Illustrated Guide to Understanding Islam  ANG MAIKLING PAGLALARAWAN NG Gabay sa Pag-unawa sa Islam"><img alt="A Brief Illustrated Guide to Understanding Islam  ANG MAIKLING PAGLALARAWAN NG Gabay sa Pag-unawa sa Islam" src="media/catalog/product/cache/1/image/139x141/9df78eab33525d08d6e5fb8d27136e95/p/h/philpinian-1.jpg"></a></div>
<div class="rgt_sec left">
<p class="bestname"><a href="a-brief-illustrated-guide-to-understanding-islam-ang-maikling-paglalarawan-ng-gabay-sa-pag-unawa-sa-islam.html" style="color:#797979;" title="A Brief Illustrated Guide to Understanding Islam  ANG MAIKLING PAGLALARAWAN NG Gabay sa Pag-unawa sa Islam">A Brief Illustrated Guide to Understanding Islam ..</a></p><a href="a-brief-illustrated-guide-to-understanding-islam-ang-maikling-paglalarawan-ng-gabay-sa-pag-unawa-sa-islam.html" style="color:#797979;" title="A Brief Illustrated Guide to Understanding Islam  ANG MAIKLING PAGLALARAWAN NG Gabay sa Pag-unawa sa Islam">
<p class="lat_price"><span style="float:left; display: block;">
</span></p><div class="price-box">
<span class="regular-price" id="product-price-2655">
<span class="price">£3.00</span> </span>
</div>

</a><a href="a-brief-illustrated-guide-to-understanding-islam-ang-maikling-paglalarawan-ng-gabay-sa-pag-unawa-sa-islam.html" style="float: right; padding-top: 4px;"><img border="0" alt="buy" src="skin/frontend/darutheme/default/images/buy.png"></a><p></p>
</div>
</li>
<li>
<div class="lft_sec left"><a href="al-quran-al-hakeem-108-arabic-only-13-lines-with-urdu-persian-hindi-script.html" title="Al Quran Al Hakeem  (108)-Arabic Only (13 lines with Urdu-Persian-Hindi Script)"><img alt="Al Quran Al Hakeem  (108)-Arabic Only (13 lines with Urdu-Persian-Hindi Script)" src="media/catalog/product/cache/1/image/139x141/9df78eab33525d08d6e5fb8d27136e95/s/c/scan0010_2_1.jpg"></a></div>
<div class="rgt_sec left">
<p class="bestname"><a href="al-quran-al-hakeem-108-arabic-only-13-lines-with-urdu-persian-hindi-script.html" style="color:#797979;" title="Al Quran Al Hakeem  (108)-Arabic Only (13 lines with Urdu-Persian-Hindi Script)">Al Quran Al Hakeem (108)-Arabic Only (13 lines wi..</a></p><a href="al-quran-al-hakeem-108-arabic-only-13-lines-with-urdu-persian-hindi-script.html" style="color:#797979;" title="Al Quran Al Hakeem  (108)-Arabic Only (13 lines with Urdu-Persian-Hindi Script)">
<p class="lat_price"><span style="float:left; display: block;">
</span></p><div class="price-box">
<span class="regular-price" id="product-price-2570">
<span class="price">£12.00</span> </span>
</div>

</a><a href="al-quran-al-hakeem-108-arabic-only-13-lines-with-urdu-persian-hindi-script.html" style="float: right; padding-top: 4px;"><img border="0" alt="buy" src="skin/frontend/darutheme/default/images/buy.png"></a><p></p>
</div>
</li>
<li class="bgnone">
<div class="lft_sec left"><a href="ahsan-al-qawaid-colour-coded-gloss-finish-paper-2578.html" title="Ahsan Al Qawaid Colour Coded (gloss finish paper)"><img alt="Ahsan Al Qawaid Colour Coded (gloss finish paper)" src="media/catalog/product/cache/1/image/139x141/9df78eab33525d08d6e5fb8d27136e95/s/c/scan0018_3.jpg"></a></div>
<div class="rgt_sec left">
<p class="bestname"><a href="ahsan-al-qawaid-colour-coded-gloss-finish-paper-2578.html" style="color:#797979;" title="Ahsan Al Qawaid Colour Coded (gloss finish paper)">Ahsan Al Qawaid Colour Coded (gloss finish paper)..</a></p><a href="ahsan-al-qawaid-colour-coded-gloss-finish-paper-2578.html" style="color:#797979;" title="Ahsan Al Qawaid Colour Coded (gloss finish paper)">
<p class="lat_price"><span style="float:left; display: block;">
</span></p><div class="price-box">
<span class="regular-price" id="product-price-2547">
<span class="price">£1.50</span> </span>
</div>

</a><a href="ahsan-al-qawaid-colour-coded-gloss-finish-paper-2578.html" style="float: right; padding-top: 4px;"><img border="0" alt="buy" src="skin/frontend/darutheme/default/images/buy.png"></a><p></p>
</div>
</li>
<li>
<div class="lft_sec left"><a href="persian-quran-tafsir-ahsan-al-kalam.html" title="Persian Quran Tafsir Ahsan Al Kalam"><img alt="Persian Quran Tafsir Ahsan Al Kalam" src="media/catalog/product/cache/1/image/139x141/9df78eab33525d08d6e5fb8d27136e95/l/r/lr01-farsi-tafseer-ahsan-ul-kalam.jpg"></a></div>
<div class="rgt_sec left">
<p class="bestname"><a href="persian-quran-tafsir-ahsan-al-kalam.html" style="color:#797979;" title="Persian Quran Tafsir Ahsan Al Kalam">Persian Quran Tafsir Ahsan Al Kalam..</a></p><a href="persian-quran-tafsir-ahsan-al-kalam.html" style="color:#797979;" title="Persian Quran Tafsir Ahsan Al Kalam">
<p class="lat_price"><span style="float:left; display: block;">
</span></p><div class="price-box">
<span class="regular-price" id="product-price-2489">
<span class="price">£14.95</span> </span>
</div>

</a><a href="persian-quran-tafsir-ahsan-al-kalam.html" style="float: right; padding-top: 4px;"><img border="0" alt="buy" src="skin/frontend/darutheme/default/images/buy.png"></a><p></p>
</div>
</li>
<li>
<div class="lft_sec left"><a href="sahih-al-bukhari-6-volume.html" title="Sahih Al Bukhari 6 Volume صحيح البخارى اردو"><img alt="Sahih Al Bukhari 6 Volume صحيح البخارى اردو" src="media/catalog/product/cache/1/image/139x141/9df78eab33525d08d6e5fb8d27136e95/d/o/doc_21_apr_2016_11-17.jpg"></a></div>
<div class="rgt_sec left">
<p class="bestname"><a href="sahih-al-bukhari-6-volume.html" style="color:#797979;" title="Sahih Al Bukhari 6 Volume صحيح البخارى اردو">Sahih Al Bukhari 6 Volume صحيح البخارى ..</a></p><a href="sahih-al-bukhari-6-volume.html" style="color:#797979;" title="Sahih Al Bukhari 6 Volume صحيح البخارى اردو">
<p class="lat_price"><span style="float:left; display: block;">
</span></p><div class="price-box">
<span class="regular-price" id="product-price-2486">
<span class="price">£99.99</span> </span>
</div>

</a><a href="sahih-al-bukhari-6-volume.html" style="float: right; padding-top: 4px;"><img border="0" alt="buy" src="skin/frontend/darutheme/default/images/buy.png"></a><p></p>
</div>
</li>
<li class="bgnone">
<div class="lft_sec left"><a href="the-qur-an-oxford-world-s-classics.html" title="The Qur'an (Oxford World's Classics)"><img alt="The Qur'an (Oxford World's Classics)" src="media/catalog/product/cache/1/image/139x141/9df78eab33525d08d6e5fb8d27136e95/o/x/oxford_quran.jpg"></a></div>
<div class="rgt_sec left">
<p class="bestname"><a href="the-qur-an-oxford-world-s-classics.html" style="color:#797979;" title="The Qur'an (Oxford World's Classics)">The Qur'an (Oxford World's Classics)..</a></p><a href="the-qur-an-oxford-world-s-classics.html" style="color:#797979;" title="The Qur'an (Oxford World's Classics)">
<p class="lat_price"><span style="float:left; display: block;">
</span></p><div class="price-box">
<span class="regular-price" id="product-price-2433">
<span class="price">£7.99</span> </span>
</div>

</a><a href="the-qur-an-oxford-world-s-classics.html" style="float: right; padding-top: 4px;"><img border="0" alt="buy" src="skin/frontend/darutheme/default/images/buy.png"></a><p></p>
</div>
</li>
</ul>
<a href="bestseller.html">View More</a>
</div>-->
</div>