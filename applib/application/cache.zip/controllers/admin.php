<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class admin extends CI_Controller {

	public function __construct() {
            parent::__construct(); 
            $this->load->model('admin_model');
        }
	public function index()
	{   
            $data['breadcrumb']=' Dashboard';
            $data['page']='admin/dashboard';
            $this->load->view('admin/template',$data);
	}
        // Main Menus
        public function main_menus()
	{   
            $data['breadcrumb']=' Main Menus';
            $data['main_menus']=$this->admin_model->get_main_menus('*');
            $data['page']='admin/main_menus/main_menus';
            $this->load->view('admin/template',$data);
	}
        public function main_menu_add(){         
            $data['breadcrumb']=' Main Menus / Add New Menu';         
            $data['post_controller']=site_url("admin/main_menu_save/");
            $data['page']='admin/main_menus/main_menu_add';
            $data['title']='';            
            $this->load->view('admin/template',$data);
	}
        public function main_menu_save(){        
            $data['name']=$this->input->post('name');
            $data['sequence']=$this->input->post('sequence');
            $data['hassub']=$this->input->post('hassub');
            $data['content']=$this->input->post('content');      
            $this->admin_model->add_main_menu($data);
            $this->session->set_userdata('msg','New Main Menu Added Successfull');
            redirect('admin/main_menus');
	}
        public function main_menu_update($id){ 
            $data['breadcrumb']=' Main Menus / Update Menu';
            $data['menu']=$this->admin_model->get_main_menu($id);         
            $data['post_controller']=site_url("admin/main_menu_edit/$id");
            $data['page']='admin/main_menus/main_menu_update';
            $data['title']='Update Main Menu';            
            $this->load->view('admin/template',$data);
	}
        public function main_menu_edit($id){ 
            $data['name']=$this->input->post('name');
            $data['sequence']=$this->input->post('sequence');
            $data['hassub']=$this->input->post('hassub');
            $data['content']=$this->input->post('content'); 
            $this->admin_model->update_main_menu($id,$data);
            $this->session->set_userdata('msg','Main Menu Updated Successfull');
            redirect('admin/main_menus');
	}
        public function main_menu_delete($id){ 
            
            $this->admin_model->delete_main_menu($id);
            $this->session->set_userdata('msg','Main Menu Deleted Successfull');
            redirect('admin/main_menus');
	}
         // Sections
        public function sections()
	{   
            $data['breadcrumb']=' Sections';
            $data['sections']=$this->admin_model->get_sections();
            $data['page']='admin/sections/sections';
            $this->load->view('admin/template',$data);
	}
        public function section_add(){         
            $data['breadcrumb']=' Sections / Add New Section';         
            $data['post_controller']=site_url("admin/section_save/");
            $data['page']='admin/sections/section_add';
            $data['title']='';            
            $this->load->view('admin/template',$data);
	}
        public function section_save(){        
            $data['name']=$this->input->post('name');     
            $this->admin_model->add_section($data);
            $this->session->set_userdata('msg','New Section Added Successfull');
            redirect('admin/sections');
	}
        public function section_update($id){ 
            $data['breadcrumb']=' Sections / Update Section';
            $data['section']=$this->admin_model->get_section($id);         
            $data['post_controller']=site_url("admin/section_edit/$id");
            $data['page']='admin/sections/section_update';
            $data['title']='Update Main Menu';            
            $this->load->view('admin/template',$data);
	}
        public function section_edit($id){ 
            $data['name']=$this->input->post('name');
            $this->admin_model->update_section($id,$data);
            $this->session->set_userdata('msg','Section Updated Successfull');
            redirect('admin/sections');
	}
        public function section_delete($id){ 
            
            $this->admin_model->delete_section($id);
            $this->session->set_userdata('msg','Section Deleted Successfull');
            redirect('admin/sections');
	}
         // Authors
        public function authors()
	{   
            $data['breadcrumb']=' Authors';
            $data['authors']=$this->admin_model->get_authors();
            $data['page']='admin/authors/authors';
            $this->load->view('admin/template',$data);
	}
        public function author_add(){         
            $data['breadcrumb']=' Authors / Add New Author';         
            $data['post_controller']=site_url("admin/author_save/");
            $data['page']='admin/authors/author_add';
            $data['title']='';            
            $this->load->view('admin/template',$data);
	}
        public function author_save(){        
            $data['name']=$this->input->post('name');     
            $this->admin_model->add_author($data);
            $this->session->set_userdata('msg','New Author Added Successfull');
            redirect('admin/authors');
	}
        public function author_update($id){ 
            $data['breadcrumb']=' Authors / Update Author';
            $data['author']=$this->admin_model->get_author($id);         
            $data['post_controller']=site_url("admin/author_edit/$id");
            $data['page']='admin/authors/author_update';
            $data['title']='Update Author';            
            $this->load->view('admin/template',$data);
	}
        public function author_edit($id){ 
            $data['name']=$this->input->post('name');
            $this->admin_model->update_author($id,$data);
            $this->session->set_userdata('msg','Author Updated Successfull');
            redirect('admin/authors');
	}
        public function author_delete($id){ 
            
            $this->admin_model->delete_author($id);
            $this->session->set_userdata('msg','Author Deleted Successfull');
            redirect('admin/authors');
	}
        // Cats
        public function cats()
	{   
            $data['breadcrumb']=' Cats';
            $data['cats']=$this->admin_model->get_cats();
            $data['page']='admin/cats/cats';
            $this->load->view('admin/template',$data);
	}
        public function cat_add(){  
            $data['sections']=$this->admin_model->get_sections();
            $data['breadcrumb']=' Cats / Add New Cat';
            
            $data['cat_controller']=site_url("admin/cat_save/");
            $data['page']='admin/cats/cat_add';
            $data['title']='';            
            $this->load->view('admin/template',$data);
	}
        public function cat_save(){
            $this->load->library('upload');
            $data['name']=$this->input->post('title');
//            $data['catContent']=$this->input->cat('text');
            $data['secId']=$this->input->post('sec');
//            $data['catDate']=$this->input->post('date');
              $config['upload_path'] = "./assets/cats_thumbs/";
            $config['allowed_types'] = 'gif|jpg|png|JPG';
            // initialize before upload
             $this->upload->initialize($config);
             $this->upload->do_upload("thumb"); 
              //[ MAIN IMAGE ]
                                    $this->load->library('image_lib'); 
//                                    echo $this->upload->file_name;
                                    $config3['image_library'] = 'gd2';
                                    $config3['source_image'] = $this->upload->upload_path.$this->upload->file_name;
                                    $config3['new_image'] = "./assets/cats_thumbs/";
                                    $config3['dest_folder'] = "./assets/cats_thumbs/";
//                                    $config3['maintain_ratio'] = TRUE;
                                    $config3['width'] = 191;
                                    $config3['height'] = 140;
                                    $this->image_lib->initialize($config3);
                                    $this->image_lib->resize();
//                                    print_r($this->image_lib);
            $data['thumb']= $this->upload->file_name;
            ///////////////////////////
//            $data['page_link_name'] = str_replace(' ', '_', $data['name']); // Replaces all spaces with hyphens.
//            preg_replace('/[^A-Za-z0-9\-]/', '', $data['page_link_name']); // Removes special chars.
//            $data['page_link_name']=$data['page_link_name'].".html";
            /////////////////////////////
            $this->admin_model->add_cat($data);
            $this->session->set_userdata('msg','New Cat Added Successfull');
            redirect('admin/cats');
	}
        public function cat_update($id){
            $data['sections']=$this->admin_model->get_sections('secId,secName');
            $data['breadcrumb']=' Cats / Update Menu';
            $data['cat']=$this->admin_model->get_cat($id);         
            $data['cat_controller']=site_url("admin/cat_edit/$id");
            $data['page']='admin/cats/cat_update';
            $data['title']='Update Cat';            
            $this->load->view('admin/template',$data);
	}
        public function cat_edit($id){ 
            $data['name']=$this->input->post('title');
            $data['secId']=$this->input->post('sec');
            if($_FILES['thumb']['name']!=null){ // if picture  selected
                $this->load->library('upload');
                    $config['upload_path'] = "./assets/cats_thumbs/";
            $config['allowed_types'] = 'gif|jpg|png|JPG';
            // initialize before upload
             $this->upload->initialize($config);
             $this->upload->do_upload("thumb"); 
              //[ MAIN IMAGE ]
                                    $this->load->library('image_lib'); 
//                                    echo $this->upload->file_name;
                                    $config3['image_library'] = 'gd2';
                                    $config3['source_image'] = $this->upload->upload_path.$this->upload->file_name;
                                    $config3['new_image'] = "./assets/cats_thumbs/";
                                    $config3['dest_folder'] = "./assets/cats_thumbs/";
//                                    $config3['maintain_ratio'] = TRUE;
                                    $config3['width'] = 191;
                                    $config3['height'] = 140;
                                    $this->image_lib->initialize($config3);
                                    $this->image_lib->resize();
//                                    print_r($this->image_lib);
            $data['thumb']= $this->upload->file_name;
                }
            ///////////////////////////
//            $data['page_link_name'] = str_replace(' ', '_', $data['name']); // Replaces all spaces with hyphens.
//            preg_replace('/[^A-Za-z0-9\-]/', '', $data['page_link_name']); // Removes special chars.
//            $data['page_link_name']=$data['page_link_name'].".html";
            /////////////////////////////
            $this->admin_model->update_cat($id,$data);
            $this->session->set_userdata('msg','Cat Updated Successfull');
            redirect('admin/cats');
	}
        public function cat_delete($id){ 
            $this->admin_model->delete_cat($id);
            $this->session->set_userdata('msg','Cat Deleted Successfull');
            redirect('admin/cats');
	}
        
        
        // Slides
        public function slides()
	{   
            $data['breadcrumb']=' Cats';
            $data['slides']=$this->admin_model->get_slides();
            $data['page']='admin/slides/slides';
            $this->load->view('admin/template',$data);
	}
        public function slide_add(){  
            $data['sections']=$this->admin_model->get_sections();
            $data['breadcrumb']=' Cats / Add New Cat';
            
            $data['post_controller']=site_url("admin/slide_save/");
            $data['page']='admin/slides/slide_add';
            $data['title']='';            
            $this->load->view('admin/template',$data);
	}
        public function slide_save(){
            $this->load->library('upload');
            $data['link']=$this->input->post('link');
              $config['upload_path'] = "./assets/slides_thumbs/";
            $config['allowed_types'] = 'gif|jpg|png|JPG';
            // initialize before upload
             $this->upload->initialize($config);
             $this->upload->do_upload("slide"); 
              //[ MAIN IMAGE ]
                                    $this->load->library('image_lib'); 
//                                    echo $this->upload->file_name;
                                    $config3['image_library'] = 'gd2';
                                    $config3['source_image'] = $this->upload->upload_path.$this->upload->file_name;
                                    $config3['new_image'] = "./assets/slides_thumbs/";
                                    $config3['dest_folder'] = "./assets/slides_thumbs/";
                                    $config3['maintain_ratio'] = false;
                                    $config3['width'] = 748;
                                    $config3['height'] = 350;
                                    $this->image_lib->initialize($config3);
                                    $this->image_lib->resize();
//                                    print_r($this->image_lib);
            $data['slide']= $this->upload->file_name;
            ///////////////////////////
//            $data['page_link_name'] = str_replace(' ', '_', $data['name']); // Replaces all spaces with hyphens.
//            preg_replace('/[^A-Za-z0-9\-]/', '', $data['page_link_name']); // Removes special chars.
//            $data['page_link_name']=$data['page_link_name'].".html";
            /////////////////////////////
            $this->admin_model->add_slide($data);
            $this->session->set_userdata('msg','New Slide Added Successfull');
            redirect('admin/slides');
	}
        public function slide_update($id){
            $data['sections']=$this->admin_model->get_sections('secId,secName');
            $data['breadcrumb']=' Cats / Update Menu';
            $data['slide']=$this->admin_model->get_slide($id);         
            $data['post_controller']=site_url("admin/slide_edit/$id");
            $data['page']='admin/slides/slide_update';
            $data['title']='Update Cat';            
            $this->load->view('admin/template',$data);
	}
        public function slide_edit($id){ 
            $data['link']=$this->input->post('link');
            if($_FILES['slide']['name']!=null){ // if picture  selected
                $this->load->library('upload');
                    $config['upload_path'] = "./assets/slides_thumbs/";
            $config['allowed_types'] = 'gif|jpg|png|JPG';
            // initialize before upload
             $this->upload->initialize($config);
             $this->upload->do_upload("slide"); 
              //[ MAIN IMAGE ]
                                    $this->load->library('image_lib'); 
//                                    echo $this->upload->file_name;
                                    $config3['image_library'] = 'gd2';
                                    $config3['source_image'] = $this->upload->upload_path.$this->upload->file_name;
                                    $config3['new_image'] = "./assets/slides_thumbs/";
                                    $config3['dest_folder'] = "./assets/slides_thumbs/";
                                    $config3['maintain_ratio'] = false;
                                    $config3['width'] = 748;
                                    $config3['height'] = 350;
                                    $this->image_lib->initialize($config3);
                                    $this->image_lib->resize();
//                                    print_r($this->image_lib);
            $data['slide']= $this->upload->file_name;
                }
            ///////////////////////////
//            $data['page_link_name'] = str_replace(' ', '_', $data['name']); // Replaces all spaces with hyphens.
//            preg_replace('/[^A-Za-z0-9\-]/', '', $data['page_link_name']); // Removes special chars.
//            $data['page_link_name']=$data['page_link_name'].".html";
            /////////////////////////////
            $this->admin_model->update_slide($id,$data);
            $this->session->set_userdata('msg','Slide Updated Successfull');
            redirect('admin/slides');
	}
        public function slide_delete($id){ 
            $this->admin_model->delete_slide($id);
            $this->session->set_userdata('msg','Cat Deleted Successfull');
            redirect('admin/slides');
	}
        
        // ads
        public function ads()
	{   
            $data['breadcrumb']=' Cats';
            $data['ads']=$this->admin_model->get_ads();
            $data['page']='admin/ads/ads';
            $this->load->view('admin/template',$data);
	}
        public function ad_add(){  
            $data['sections']=$this->admin_model->get_sections();
            $data['breadcrumb']=' Cats / Add New Cat';
            
            $data['post_controller']=site_url("admin/ad_save/");
            $data['page']='admin/ads/ad_add';
            $data['title']='';            
            $this->load->view('admin/template',$data);
	}
        public function ad_save(){
            $this->load->library('upload');
            $data['link']=$this->input->post('link');
              $config['upload_path'] = "./assets/ads_thumbs/";
            $config['allowed_types'] = 'gif|jpg|png|JPG';
            // initialize before upload
             $this->upload->initialize($config);
             $this->upload->do_upload("ad"); 
              //[ MAIN IMAGE ]
                                    $this->load->library('image_lib'); 
//                                    echo $this->upload->file_name;
                                    $config3['image_library'] = 'gd2';
                                    $config3['source_image'] = $this->upload->upload_path.$this->upload->file_name;
                                    $config3['new_image'] = "./assets/ads_thumbs/";
                                    $config3['dest_folder'] = "./assets/ads_thumbs/";
                                    $config3['maintain_ratio'] = TRUE;
                                    $config3['width'] = 207;
//                                    $config3['height'] = 350;
                                    $this->image_lib->initialize($config3);
                                    $this->image_lib->resize();
//                                    print_r($this->image_lib);
            $data['ad']= $this->upload->file_name;
            ///////////////////////////
//            $data['page_link_name'] = str_replace(' ', '_', $data['name']); // Replaces all spaces with hyphens.
//            preg_replace('/[^A-Za-z0-9\-]/', '', $data['page_link_name']); // Removes special chars.
//            $data['page_link_name']=$data['page_link_name'].".html";
            /////////////////////////////
            $this->admin_model->add_ad($data);
            $this->session->set_userdata('msg','New ad Added Successfull');
            redirect('admin/ads');
	}
        public function ad_update($id){
            $data['sections']=$this->admin_model->get_sections('secId,secName');
            $data['breadcrumb']=' Cats / Update Menu';
            $data['ad']=$this->admin_model->get_ad($id);         
            $data['ad_controller']=site_url("admin/ad_edit/$id");
            $data['page']='admin/ads/ad_update';
            $data['title']='Update Cat';            
            $this->load->view('admin/template',$data);
	}
        public function ad_edit($id){ 
            $data['link']=$this->input->post('link');
            if($_FILES['ad']['name']!=null){ // if picture  selected
                $this->load->library('upload');
                    $config['upload_path'] = "./assets/ads_thumbs/";
            $config['allowed_types'] = 'gif|jpg|png|JPG';
            // initialize before upload
             $this->upload->initialize($config);
             $this->upload->do_upload("ad"); 
              //[ MAIN IMAGE ]
                                    $this->load->library('image_lib'); 
//                                    echo $this->upload->file_name;
                                    $config3['image_library'] = 'gd2';
                                    $config3['source_image'] = $this->upload->upload_path.$this->upload->file_name;
                                    $config3['new_image'] = "./assets/ads_thumbs/";
                                    $config3['dest_folder'] = "./assets/ads_thumbs/";
                                    $config3['maintain_ratio'] = TRUE;
                                    $config3['width'] = 207;
//                                    $config3['height'] = 350;
                                    $this->image_lib->initialize($config3);
                                    $this->image_lib->resize();
//                                    print_r($this->image_lib);
            $data['ad']= $this->upload->file_name;
                }
            ///////////////////////////
//            $data['page_link_name'] = str_replace(' ', '_', $data['name']); // Replaces all spaces with hyphens.
//            preg_replace('/[^A-Za-z0-9\-]/', '', $data['page_link_name']); // Removes special chars.
//            $data['page_link_name']=$data['page_link_name'].".html";
            /////////////////////////////
            $this->admin_model->update_ad($id,$data);
            $this->session->set_userdata('msg','ad Updated Successfull');
            redirect('admin/ads');
	}
        public function ad_delete($id){ 
            $this->admin_model->delete_ad($id);
            $this->session->set_userdata('msg','Cat Deleted Successfull');
            redirect('admin/ads');
	}
        
        // Products
        public function products()
	{   
            $data['breadcrumb']=' Cats';
            $data['products']=$this->admin_model->get_products();
            $data['page']='admin/products/products';
            $this->load->view('admin/template',$data);
	}
        public function product_add(){  
            $data['cats']=$this->admin_model->get_cats();
//            $data['authors']=$this->admin_model->get_authors();
            $data['breadcrumb']=' Cats / Add New Cat';
            
            $data['product_controller']=site_url("admin/product_save/");
            $data['page']='admin/products/product_add';
            $data['title']='';            
            $this->load->view('admin/template',$data);
	}
        public function product_save(){
            $this->load->library('upload');
            $data['productTitle']=$this->input->post('title');
            $data['price']=$this->input->post('price');
            $data['catId']=$this->input->post('cat');
            $data['specs']=$this->input->post('specs');
            $data['productDate']=$this->input->post('date');
            $data['description']=$this->input->post('description');
            $config['upload_path'] = "./assets/products_thumbs/";
            $config['allowed_types'] = 'gif|jpg|png|JPG';
            // initialize before upload
             $this->upload->initialize($config);
             $this->upload->do_upload("thumb"); 
              //[ MAIN IMAGE ]
                                    $this->load->library('image_lib'); 
//                                    echo $this->upload->file_name;
                                    $config3['image_library'] = 'gd2';
                                    $config3['source_image'] = $this->upload->upload_path.$this->upload->file_name;
                                    $config3['new_image'] = "./assets/products_thumbs/";
                                    $config3['dest_folder'] = "./assets/products_thumbs/";
                                    $config3['height'] = 542;
                                    $config3['width'] = 400;
                                    $config3['maintain_ratio'] = false;
                                    $this->image_lib->initialize($config3);
                                    $this->image_lib->resize();
//                                    print_r($this->image_lib);
            $data['thumb']= $this->upload->file_name;
            ///////////////////////////
//            $data['page_link_name'] = str_replace(' ', '_', $data['name']); // Replaces all spaces with hyphens.
//            preg_replace('/[^A-Za-z0-9\-]/', '', $data['page_link_name']); // Removes special chars.
//            $data['page_link_name']=$data['page_link_name'].".html";
            /////////////////////////////
            $this->admin_model->add_product($data);
            $this->session->set_userdata('msg','New Cat Added Successfull');
            redirect('admin/products');
	}
        public function product_update($id){
            $data['cats']=$this->admin_model->get_cats();
//            $data['authors']=$this->admin_model->get_authors();
            $data['breadcrumb']=' Cats / Update Product';
            $data['product']=$this->admin_model->get_product($id);         
            $data['product_controller']=site_url("admin/product_edit/$id");
            $data['page']='admin/products/product_update';
            $data['title']='Update Cat';            
            $this->load->view('admin/template',$data);
	}
        public function product_edit($id){ 
            $data['productTitle']=$this->input->post('title');
            $data['price']=$this->input->post('price');
            $data['description']=$this->input->post('description');
            $data['catId']=$this->input->post('cat');
            $data['specs']=$this->input->post('specs');
            $data['productDate']=$this->input->post('date');
            ///////////////////////////
//            $data['page_link_name'] = str_replace(' ', '_', $data['name']); // Replaces all spaces with hyphens.
//            preg_replace('/[^A-Za-z0-9\-]/', '', $data['page_link_name']); // Removes special chars.
//            $data['page_link_name']=$data['page_link_name'].".html";
            /////////////////////////////
            $this->admin_model->update_product($id,$data);
            $this->session->set_userdata('msg','Cat Updated Successfull');
            redirect('admin/products');
	}
        public function product_delete($id){ 
            $this->admin_model->delete_product($id);
            $this->session->set_userdata('msg','Cat Deleted Successfull');
            redirect('admin/products');
	}
        public function order($id){ 
            $this->admin_model->delete_product($id);
            $this->session->set_userdata('msg','Cat Deleted Successfull');
            redirect('admin/products');
        }
        
        // Orders
        public function orders()
	{   
            $data['breadcrumb']=' Orders';
            $data['orders']=$this->admin_model->get_orders();
            $data['page']='admin/orders/orders';
            $this->load->view('admin/template',$data);
	}
        public function order_save($id){
            $data['customerName']=$this->input->post('name');
            $data['Contact']=$this->input->post('contact');
            $data['productId']=$id;
            $data['quantity']=$this->input->post('quantity');
            $data['address']=$this->input->post('address');
            date_default_timezone_set('Asia/Karachi');
            $data['date']=date('Y-m-d h:i');
            $this->admin_model->add_order($data);
            $this->session->set_userdata('msg','Your Order Has been Placed Successfull');
            redirect("home/product_details/$id");
	}
        public function update_order_status($id){
            $this->admin_model->update_order($id);
            $this->session->set_userdata('msg','Order Status Updated Successfull');
            redirect('admin/orders');
	}
        public function order_delete($id){ 
            $this->admin_model->delete_order($id);
            $this->session->set_userdata('msg','Order Deleted Successfull');
            redirect('admin/orders');
	}
        
        // Subs
        public function subs()
	{   
            $data['breadcrumb']=' Subscriptions';
            $data['emails']=$this->admin_model->get_emails();
            $data['mobiles']=$this->admin_model->get_mobiles();
            $data['page']='admin/subscribes/subs';
            $this->load->view('admin/template',$data);
	}
      
}
