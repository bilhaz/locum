<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class home extends CI_Controller {
        public function __construct() {
            parent::__construct(); 
            $this->load->model('admin_model');
        }
	public function index()
	{   
//	$this->load->helper('text');
            $data['sections']=$this->admin_model->get_sections();
            $data['slides']=$this->admin_model->get_slides();
            $data['page']='home';
            $this->load->view('template',$data);
	}
        public function products($cat)
	{   
            $res=$this->admin_model->get_cat($cat);
            $data['catName']=$res['name'];
            $data['products']=$this->admin_model->get_products_by_cat($cat);
            $data['page']='products';
            $this->load->view('template',$data);
	}
        public function product_details($id)
	{   
            $data['product']=$this->admin_model->get_product($id);
            $data['page']='product_details';
            $this->load->view('template',$data);
	}
        public function pages($id)
	{   
            $data['pages']=$this->admin_model->get_main_menu($id);
            $data['page']='main_pages';
            $this->load->view('template',$data);
	}
        public function search()
	{   
            $data['catName']='نتائج';
            $data['products']=$this->admin_model->get_products_by_search($this->input->post('search'));
            $data['page']='products';
            $this->load->view('template',$data);
	}
        public function email_subscribe(){
            $this->load->library('form_validation');
            $this->form_validation->set_rules('email','Email','valid_email|required|unique[subs_email.email]');
            $data['email']=$this->input->post('email');
            if($this->form_validation->run() == FALSE){
                    print '<script type="text/javascript">'."alert('".  trim(preg_replace('/\s\s+/', ' ', strip_tags(validation_errors()))) .". Please Try Again');document.location='".site_url($this->input->get('url'))."';
                         </script>";
            }
           else {
               $this->admin_model->add_email($data);
               print '<script type="text/javascript">'."alert('Congrats! Your Email has been registered, Your will get our products news.');document.location='".site_url($this->input->get('url'))."';
                         </script>";
           }
            
	}
        public function mobile_subscribe()
	{   
             $this->load->library('form_validation');
            $this->form_validation->set_rules('mobile','Mobile Number','numeric|required|min_length[11]|max_length[11]');
            $data['mobile']=$this->input->post('mobile');
            if($this->form_validation->run() == FALSE){
                    print '<script type="text/javascript">'."alert('".  trim(preg_replace('/\s\s+/', ' ', strip_tags(validation_errors()))) .". Please Try Again');document.location='".site_url($this->input->get('url'))."';
                         </script>";
            }
           else {
               $this->admin_model->add_mobile($data);
               print '<script type="text/javascript">'."alert('Congrats! Your Mobile Number has been registered, Your will get our products news.');document.location='".site_url($this->input->get('url'))."';
                         </script>";
           }
	}
        
        
}
