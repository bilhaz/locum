<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
    class admin_model extends CI_Model {
      
        // Main Menu
        public function get_main_menus($fields){
            $this->db->select($fields);   
            $query=$this->db->get('main_menus');
            $result=$query->result();
            return $result;
        }
        public function get_main_menu($id){
            $this->db->select('*');  
            $this->db->where('mmId',$id); 
            $query=$this->db->get('main_menus');
            $result=$query->row_array();
            return $result;
        }
        function add_main_menu($data){
            $this->db->insert('main_menus', $data);
        }
        function update_main_menu($id,$data){
            $this->db->where('mmId',$id);
            $this->db->update('main_menus', $data);
        }
        function delete_main_menu($id){
            $this->db->where('mmId',$id);
            $this->db->delete('main_menus');
        }
        // Sections
        public function get_sections(){
            $this->db->select('*'); 
//            $this->db->order_by('secId','Asc'); 
            $this->db->order_by('order_no','Asc');
            $query=$this->db->get('sections');
            $result=$query->result();
            return $result;
        }
        public function get_section($id){
            $this->db->select('*');  
            $this->db->where('secId',$id); 
            $this->db->order_by('order_no','Asc');
            $query=$this->db->get('sections');
            $result=$query->row_array();
            return $result;
        }
        function add_section($data){
            $this->db->insert('sections', $data);
        }
        function update_section($id,$data){
            $this->db->where('secId',$id);
            $this->db->update('sections', $data);
        }
        function delete_section($id){
            $this->db->where('secId',$id);
            $this->db->delete('sections');
            $this->db->where('secId',$id);
            $this->db->delete('categories');
        }
        // Authors
        public function get_authors(){
            $this->db->select('*'); 
            $query=$this->db->get('authors');
            $result=$query->result();
            return $result;
        }
        public function get_author($id){
            $this->db->select('*');  
            $this->db->where('authId',$id); 
            $query=$this->db->get('authors');
            $result=$query->row_array();
            return $result;
        }
        function add_author($data){
            $this->db->insert('authors', $data);
        }
        function update_author($id,$data){
            $this->db->where('authId',$id);
            $this->db->update('authors', $data);
        }
        function delete_author($id){
            $this->db->where('authId',$id);
            $this->db->delete('authors');
        }
       // Cats
        public function get_cats(){
            $this->db->select('categories.*,sections.name as secName');  
            $this->db->join('sections','categories.secId=sections.secId'); 
            $this->db->order_by('catId','Asc'); 
            $query=$this->db->get('categories');
            $result=$query->result();
            return $result;
        }
        public function get_cats_by_section($id){
            
            $this->db->select('categories.name,categories.catId,thumb');  
            $this->db->where('secId',$id); 
            $this->db->limit(3,0); 
            $this->db->order_by('catId','Desc'); 
            $query=$this->db->get('categories');
            $result=$query->result();
            return $result;
        }
        public function get_cats_by_section2($id){
            
            $this->db->select('categories.name,categories.catId,thumb');  
            $this->db->where('secId',$id); 
            $this->db->order_by('catId','Desc'); 
            $query=$this->db->get('categories');
            $result=$query->result();
            return $result;
        }
        public function get_cat($id){
            $this->db->select('*');  
            $this->db->where('catId',$id); 
            $query=$this->db->get('categories');
            $result=$query->row_array();
            return $result;
        }
        public function get_cat_details($id){
            $this->db->select('*');  
            $this->db->where('catId',$id); 
            $this->db->join('sections','tbl_section.secId=categories.secId');  
            $query=$this->db->get('categories');
            $result=$query->row_array();
            return $result;
        }
        function add_cat($data){
            $this->db->insert('categories', $data);
        }
        function update_cat($id,$data){
            $this->db->where('catId',$id);
            $this->db->update('categories', $data);
        }
        function delete_cat($id){
            $this->db->select('thumb');  
            $this->db->where('catId',$id); 
            $query=$this->db->get('categories');
            $result=$query->row_array();
            unlink('./assets/cats_thumbs/'.$result['catThumb']);
            $this->db->where('catId',$id);
            $this->db->delete('categories');
            $this->db->where('catId',$id);
            $this->db->delete('products');
        }       
        
        // Slide
        public function get_slides(){
            $this->db->select('*');  
            $this->db->order_by('slideId','Asc'); 
            $query=$this->db->get('slides');
            $result=$query->result();
            return $result;
        }
        public function get_slides_by_section($id){
            
            $this->db->select('*');  
            $this->db->where('secId',$id); 
            $query=$this->db->get('slides');
            $result=$query->result();
            return $result;
        }
        public function get_slide($id){
            $this->db->select('*');  
            $this->db->where('slideId',$id); 
            $query=$this->db->get('slides');
            $result=$query->row_array();
            return $result;
        }
        public function get_slide_details($id){
            $this->db->select('*');  
            $this->db->where('slideId',$id); 
            $query=$this->db->get('slides');
            $result=$query->row_array();
            return $result;
        }
        function add_slide($data){
            $this->db->insert('slides', $data);
        }
        function update_slide($id,$data){
            $this->db->where('slideId',$id);
            $this->db->update('slides', $data);
        }
        function delete_slide($id){
            $this->db->select('slide');  
            $this->db->where('slideId',$id); 
            $query=$this->db->get('slides');
            $result=$query->row_array();
            unlink('./assets/slides_thumbs/'.$result['slide']);
            $this->db->where('slideId',$id);
            $this->db->delete('slides');
        }  
        
        
        // Ads
        public function get_ads(){
            $this->db->select('*');  
            $this->db->order_by('adId','Asc'); 
            $query=$this->db->get('ads');
            $result=$query->result();
            return $result;
        }
        public function get_ads_by_section($id){
            
            $this->db->select('*');  
            $this->db->where('secId',$id); 
            $query=$this->db->get('ads');
            $result=$query->result();
            return $result;
        }
        public function get_ad($id){
            $this->db->select('*');  
            $this->db->where('adId',$id); 
            $query=$this->db->get('ads');
            $result=$query->row_array();
            return $result;
        }
        public function get_ad_details($id){
            $this->db->select('*');  
            $this->db->where('adId',$id); 
            $query=$this->db->get('ads');
            $result=$query->row_array();
            return $result;
        }
        function add_ad($data){
            $this->db->insert('ads', $data);
        }
        function update_ad($id,$data){
            $this->db->where('adId',$id);
            $this->db->update('ads', $data);
        }
        function delete_ad($id){
            $this->db->select('thumb');  
            $this->db->where('adId',$id); 
            $query=$this->db->get('ads');
            $result=$query->row_array();
            unlink('./assets/ads_thumbs/'.$result['ad']);
            $this->db->where('adId',$id);
            $this->db->delete('ads');
        }  
        // Products
        public function get_products(){
            $this->db->select('products.*,categories.name as catName');  
            $this->db->join('categories','categories.catId=products.catId'); 
//            $this->db->join('authors','authors.authId=products.authId'); 
            $query=$this->db->get('products');
            $result=$query->result();
            return $result;
        }
        public function get_product($id){
            $this->db->select('*');  
            $this->db->where('productId',$id); 
//            $this->db->join('authors','authors.authId=products.authId'); 
            $query=$this->db->get('products');
            $result=$query->row_array();
            return $result;
        }
        public function get_products_by_section($id){
            $this->db->select('*');  
            $this->db->join('products','products.catId=categories.catId'); 
            $this->db->join('sections','sections.secId=categories.secId'); 
            $this->db->where('sections.secId',$id);
            $this->db->order_by('products.productDate','Desc');
            $this->db->limit(6,0);
            $query=$this->db->get('categories');
            $result=$query->result();
            return $result;
        }
        public function get_products_by_search($srch){
            $this->db->select('*'); 
            $this->db->like('productTitle',$srch);  
            $this->db->order_by('products.productDate','Desc');
            $query=$this->db->get('products');
            $result=$query->result();
            return $result;
        }
        
        public function get_products_by_cat($id){
            $this->db->select('*');  
//            $this->db->join('categories','products.catId=categories.catId'); 
            $this->db->where('products.catId',$id);
            $this->db->order_by('products.productDate','Desc');
            $query=$this->db->get('products');
            $result=$query->result();
            return $result;
        }
        public function get_product_details($id){
            $this->db->select('*');  
            $this->db->where('productId',$id); 
            $this->db->join('categories','categories.catId=products.catId');  
            $query=$this->db->get('products');
            $result=$query->row_array();
            return $result;
        }
        function add_product($data){
            $this->db->insert('products', $data);
        }
        function update_product($id,$data){
            $this->db->where('productId',$id);
            $this->db->update('products', $data);
        }
        function delete_product($id){
            $this->db->select('thumb');  
            $this->db->where('productId',$id); 
            $query=$this->db->get('products');
            $result=$query->row_array();
            unlink('./assets/products_thumbs/'.$result['productThumb']);
            $this->db->where('productId',$id);
            $this->db->delete('products');
        }
        
        // 
        function add_email($data){
            $this->db->insert('subs_email', $data);
        }
         public function get_emails(){
            $this->db->select('*');  
            $query=$this->db->get('subs_email');
             return $query->result_array();
        }
        function add_mobile($data){
            $this->db->insert('subs_mobile', $data);
        }
        public function get_mobiles(){
            $this->db->select('*');  
            $query=$this->db->get('subs_mobile');
             return $query->result_array();
        }
        function add_order($data){
            $this->db->insert('orders', $data);
        }
        public function get_orders(){
            $this->db->select('orders.*,products.productTitle');  
            $this->db->join('products','orders.productId=products.productId'); 
            $query=$this->db->get('orders');
            $result=$query->result();
            return $result;
        }
        public function update_order($id){
            $this->db->where('orderNo',$id);
            $this->db->set('status',1);
            $this->db->update('orders');
        }
        function delete_order($id){
            $this->db->where('orderNo',$id);
            $this->db->delete('orders');
        }
       
    }
    

