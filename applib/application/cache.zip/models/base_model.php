
<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
    class base_model extends CI_Model {
      
        // Main Menu
        public function get_main_menus($fields){
            $this->db->select($fields);
            $this->db->order_by('sequence','ASC');
            $query=$this->db->get('main_menus');
            $result=$query->result();
            return $result;
        }
        // Sub Menu
//        public function get_sub_menus($fields){
//            $this->db->select($fields);  
//            $this->db->join('main_menus','sub_menus.mmId=main_menus.mmId'); 
//            $query=$this->db->get('sub_menus');
//            $result=$query->result();
//            return $result;
//        }
        public function get_sub_menus($id){
            $this->db->select('*');  
            $this->db->order_by('sequence','ASC');
            $this->db->where('mmId',$id); 
            $query=$this->db->get('sub_menus');
            $result=$query->result();
            return $result;
        }
        function add_sub_menu($data){
            $this->db->insert('sub_menus', $data);
        }
        function update_sub_menu($id,$data){
            $this->db->where('subId',$id);
            $this->db->update('sub_menus', $data);
        }
        function delete_sub_menu($id){
            $this->db->where('subId',$id);
            $this->db->delete('sub_menus');
        }
        public function get_events(){
            $this->db->select('*');  
            $query=$this->db->get('tbl_event');
            $result=$query->result();
            return $result;
        }
        public function get_sections(){
            $this->db->select('*');  
            $query=$this->db->get('tbl_section');
            $result=$query->result();
            return $result;
        }
        public function get_news(){
            $this->db->select('*');  
            $this->db->order_by('newsDate','DSC');
            $this->db->where('visible',1);
            $query=$this->db->get('tbl_news');
            $result=$query->result();
            return $result;
        }
        public function get_activities_years($id){
            $this->db->distinct();
            $this->db->select('actYear');  
            $this->db->where('eventId',$id);
            $query=$this->db->get('tbl_activity');
            $result=$query->result();
//            echo $this->db->last_query();
            return $result;
        }
        public function get_pictures($id){
            $this->db->select('img');  
            $this->db->where('actId',$id);
            $query=$this->db->get('uploads');
            $result=$query->row_array();
//            echo $this->db->last_query();
            if($this->db->affected_rows()){
             $array=explode(',', $result['img']);
              array_pop($array);
              return $array;
            }
            else return FALSE;
        }
        
        public function get_upcoming_activities(){
                date_default_timezone_set("Asia/Karachi"); 
                $date=date('Y-m-d'); //Returns IST 
                $data=$this->db->query("select * from tbl_activity where actStartDate > '$date' ORDER BY actStartDate DESC");
//               echo $this->db->last_query();exit;
                return $data->result();
        }
        public function get_latest_posts(){
            $this->db->select('tbl_post.*,tbl_section.secName as section');  
            $this->db->order_by('postDate','DESC');  
            $this->db->limit(6);  
            $this->db->join('tbl_section','tbl_section.secId=tbl_post.secId');  
            $query=$this->db->get('tbl_post');
            return $query->result();
        }
        public function get_latest_pics(){
            $this->db->select('*');  
            $this->db->order_by('actEndDate','DESC');  
            $this->db->join('uploads','uploads.actId=tbl_activity.actId');  
            $query=$this->db->get('tbl_activity');
            return $query->result();
        }
        function get_folder_name($id){
            $this->db->select('tbl_event.folderName');  
            $this->db->where('eventId',$id);
            $query=$this->db->get('tbl_event');
            $result=$query->row_array();
            return $result['folderName'];
        }
        
                
    }
    

